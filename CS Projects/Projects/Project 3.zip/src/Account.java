public class Account {
    private long balance;
    //balance is an integer value to simply keep people from entering deposit values less than .01,
    //instead defaulting inputs to being in single-cent values (ie 1$ = 100c = balance + 100)
    //This does require more memory and processing, but keeps balances within real-world standard american currency
    private int accountNumber;
    private static int numberOfAccounts = 1000;

    public Account(double initialDeposit){
        numberOfAccounts++;
        balance = (long)(initialDeposit * 100);
        //ex: 1$ entered
        //100c added to balance
        //ex: 1.05$ entered
        //105c added to balance
        //ex: 1.051$ added
        //105c added to balance
        System.out.println((((double)balance)/100) + " dollars added");
        accountNumber = numberOfAccounts;
    }

    public void deposit(double deposit){
        balance += (long)(deposit * 100);
        System.out.println("\t New Balance: $" + (((double)balance)/100));
    }

    public void withdraw(double withdraw){
        if (((long)(withdraw*100)) > balance){
            System.out.println("!!Insufficient funds. Withdraw cancelled.");
        }
        else{
            balance -= ((long)(withdraw*100));
        }
        System.out.println("Current Balance: $" + ((double)balance)/100);
    }

    public int getAccountNumber(){
        return accountNumber;
    }



    public String toString(){
        return ("Account Number: " + accountNumber + "\n\t- Balance: $" + ((double)balance)/100);
    }

    //things that would be pretty cool:
    //a simple few private methods to automate the shift in input (c to $ and $ to c) so that the code is easier to read
}
