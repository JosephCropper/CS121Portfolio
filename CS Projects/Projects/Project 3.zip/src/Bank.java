import java.util.ArrayList;
public class Bank {
    private ArrayList<Customer> customers = new ArrayList<>();

    public void addCustomer(Customer customer){
        customers.add(customer);
    }

    public void removeCustomer(Customer customer){
        customers.remove(customer);
    }

    public Customer searchByPin(int pin){
        for (Customer i : customers){
            if (i.getPin() == pin){
                return i;
            }
        }
        return null;
    }

    public String getAllCustomerInfo(){
        String returnString = "";
        for (Customer i : customers){
            returnString = returnString + i.toString() + "\n";
        }
        return returnString;
    }
}
