import java.util.ArrayList;
public class Customer {
    private String fName, lName;
    private int pin;
    private ArrayList<Account> customerAccounts = new ArrayList<Account>();

    public Customer(String firstName, String lastName, int PIN){
        fName = firstName;
        lName = lastName;
        pin = PIN;
    }

    public void addAccount(Account account){
        customerAccounts.add(account);
    }

    public void removeAccount(Account account){
        customerAccounts.remove(account);
    }

    public Account getAccountByNumber(int accountnumber){
        for (Account i : customerAccounts){
            if (i.getAccountNumber() == accountnumber){
                return i;
            }
        }
        return null;
    }

    public String getAllAccountData(){
        String returnString = "";
        for (Account i : customerAccounts){
            returnString = returnString + i.toString() + "\n";
        }
        return returnString;
    }

    public int getPin(){
        return pin;
    }

    public String toString(){
        return ("First Name: " + fName + "| Last Name: " + lName + "| PIN: " + pin);
    }
}
