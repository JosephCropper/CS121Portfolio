import java.util.Scanner;
public class Menu {
    private Scanner scan = new Scanner(System.in);
    private Bank bank = new Bank();

    public void displayMenu() {

        System.out.println("---------- Menu ----------" +
                "\n\n 1) Access account" +
                "\n 2) Open new account" +
                "\n 3) Close all accounts" +
                "\n Exit");
        try {
            switch (scan.nextInt()) {
                case 1:
                    accessAccount();
                    break;
                case 2:
                    openNewAccount();
                    break;
                case 3:
                    closeAll();
                    break;
                case 4:
                    System.out.println("Exiting...");
                    System.exit(0);
                    return;
                default:
                    System.err.println("Invalid input, returning...");
                    return;
            }
        } catch (Exception e) {
            System.err.println("Invalid input, returning...");
            return;
        }
    }

    private Customer createNewCustomer() {
        System.out.println("Enter your first name, last name, pin, and deposit for your first account:");
        try {
            String fname = scan.next();
            String lname = scan.next();
            int pinInput = scan.nextInt();
            bank.addCustomer(new Customer(fname, lname, pinInput));
            return bank.searchByPin(pinInput);
        }
        catch(Exception e){
            System.err.println("Invalid input, returning...");
            return null;
        }
    }

    private void accessAccount(){
        boolean loop = true;
        while(loop) {
            System.out.println("Please insert pin: ");
            try {
                int pinInput = scan.nextInt();
                if (bank.searchByPin(pinInput) == null) {
                    System.err.println("Invalid PIN, returning...");
                    return;
                } else {
                    System.out.println(bank.searchByPin(pinInput).getAllAccountData() +
                            "\nEnter the account number you would like to access: ");
                    try {

                        int accountSelection = scan.nextInt();
                        if (bank.searchByPin(pinInput).getAccountByNumber(accountSelection) == null) {
                            System.err.println("Invalid Account, returning...");
                        } else {
                            System.out.println("---------- Account Menu ----------" +
                                    "\n\n 1) Make Deposit" +
                                    "\n 2) Make a Withdrawal" +
                                    "\n 3) See Account Balance" +
                                    "\n 4) Close Account" +
                                    "\n 5) Exit");
                            try {
                                switch (scan.nextInt()) {
                                    case 1:
                                        System.out.println("Enter the amount you want to deposit: ");
                                        try {
                                            bank.searchByPin(pinInput).getAccountByNumber(accountSelection).deposit(scan.nextDouble());
                                        } catch (Exception e) {
                                            System.out.println("Invalid input, returning...");
                                            return;
                                        }
                                        break;
                                    case 2:
                                        System.out.println("Enter the amount you want to withdraw: ");
                                        try {
                                            bank.searchByPin(pinInput).getAccountByNumber(accountSelection).withdraw(scan.nextDouble());
                                        } catch (Exception e) {
                                            System.out.println("Invalid input, returning... ");
                                            return;
                                        }
                                        break;
                                    case 3:
                                        System.out.println(bank.searchByPin(pinInput).getAccountByNumber(accountSelection).toString());
                                        break;
                                    case 4:
                                        bank.searchByPin(pinInput).removeAccount(bank.searchByPin(pinInput).getAccountByNumber(accountSelection));
                                        System.out.println("Removed successfully.");
                                        break;
                                    case 5:
                                        loop = false;
                                        return;
                                    default:
                                        System.err.println("Invalid input, returning...");
                                        return;
                                }
                            } catch (Exception e) {
                                System.err.println("Invalid input, returning...");
                            }
                        }
                    } catch (Exception e) {
                        System.err.println("Invalid input, returning...");
                        return;
                    }
                }
            } catch (Exception e) {
                System.err.println("Invalid input, returning...");
                return;
            }
        }
    }

    private void openNewAccount(){
        System.out.println("Are you a new customer? 1 for yes, 2 for no");
        try {
            switch (scan.nextInt()) {
                case 1:
                    Customer tempCustomer = createNewCustomer();
                    System.out.println("Enter a deposit: ");
                    Account tempAccount = new Account(scan.nextDouble());
                    tempCustomer.addAccount(tempAccount);
                    System.out.println("Account number: " + tempAccount.getAccountNumber());
                    this.displayMenu();
                    break;
                case 2:
                    System.out.println("Please insert your pin: ");
                    try {
                        int pinInput = scan.nextInt();
                        if (bank.searchByPin(pinInput) == null) {
                            System.out.println("PIN not found. returning to menu...");
                            this.displayMenu();
                            return;
                        } else {
                            System.out.println("Please insert your deposit amount: ");

                            bank.searchByPin(pinInput).addAccount(new Account(scan.nextDouble()));
                            System.out.println("New account created.");
                        }
                    } catch (Exception e) {
                        System.err.println("Invalid input, returning...");
                        return;
                    }
                    break;
                default:
                    System.err.println("Invalid input, returning...");
                    return;
            }
        } catch (Exception e) {
            System.err.println("Invalid input, returning...");
            return;
        }
    }

    private void closeAll(){
        System.out.println("Enter your pin: ");
        try{
            int pinInput = scan.nextInt();
            if(bank.searchByPin(pinInput) != null){
                bank.removeCustomer(bank.searchByPin(pinInput));
                System.out.println("You have been removed from the bank.");
            }
            else{
                System.out.println("Pin not found. returning...");
                this.displayMenu();
                return;
            }
        }
        catch(Exception e){
            System.err.println("Invalid input, returning...");
            return;
        }
    }
}
