import java.util.Scanner;
import java.util.Random;
import java.io.File;


public class Main {
    public static void main(String[] args) {


        /*
        Did i go a *little* overboard? Probably.
        Is this code the finest italian pasta? It's certainly spaghetti.
        Are there probably more bugs in here than realistically encounterable in a single human lifespan? Oh absolutely.
        Should i have used the time i spent on this to do ZyBooks? yeah.

        Does it work? Enough

        In my defense, i was bored, and the pokemon example made me think about the internal algorithms of the actual videogame series, and now we both have to deal with the consequences of it.
         */


        //File init
        File fpokemon = new File("./Resources/Pokemon.txt");

        //--------------------------------------------------------------
        //Scanner Variables
        Random rand = new Random();
        Scanner scan = new Scanner(System.in);

        Scanner pokemon = new Scanner(System.in);


        try{
            pokemon = new Scanner(fpokemon);

        }
        catch (Exception e){
        }
        //------------------------------------

        //Basic Variable Types
        Pokemon[][] teams = new Pokemon[0][0];

        String activeMonT1 = "";
        String activeMonT2 = "";
        String dexRead = "";
        String userInput = "";
        int teamOneActive = -1;
        int teamTwoActive = -1;
        int pokemonPerTeam = 0;
        int numberOfRounds = 0;
        int weatherTimer = 0;
        int livingMons1 = 6;
        int livingMons2 = 6;
        int trainerPickOrder = -1;
        int trainerOneMove = -1;
        int trainerTwoMove = -1;
        enum Weather{
            clear, sandstorm, halestorm;
        }
        Weather weather = Weather.clear;
        boolean typeEnterCheck = false;
        boolean thatMonIsReal = false;
        boolean moldBreaker = false;
        boolean winCondition = false;
        boolean trainer1switch = false;
        boolean trainer2switch = false;
        boolean acceptedInput = false;
        boolean switchableMon = false;
        boolean acceptedMove = false;
        boolean trainer1NeedSwitch = true;
        boolean trainer2NeedSwitch = true;



        System.out.println("Hello!");
        //Initialize teams
        while(!typeEnterCheck){

            System.out.print("Please enter the amount of pokemon on each team ( 1 - 6 ): ");
            pokemonPerTeam = scan.nextInt();

            if (pokemonPerTeam > 0 && pokemonPerTeam < 7){

                typeEnterCheck = true;
                teams = new Pokemon[2][pokemonPerTeam];

                for (int x = 0; x < 2; x++) {
                    for (int i = 0; i < pokemonPerTeam; i++) {
                        teams[x][i] = new Pokemon();
                        teams[x][i].pokemon();
                    }
                }

            }

        }

        //Get Pokemon for teams

        for (int team = 1; team <= 2; team++){

            for (int pokemonNumber = 1; pokemonNumber <= pokemonPerTeam; pokemonNumber++){

                thatMonIsReal = false;
                System.out.print("\n(Team " + team + "| Pokemon " + pokemonNumber + ") Enter:\na) \"list\" to see the list of available pokemon\nb)The name of the Pokemon you'd like to add to your team\n\t");
                userInput = scan.next();

                switch(userInput){

                    case ("list"):
                        System.out.print("\n\n--------------\nPokemon\nTorterra, Infernape, Empoleon, Staraptor, Bibarel, \nKricketune, Luxray, Roserade, Rampardos, Bastiodon,\n -Vespiquen, Floatzel, Gastrodon, Drifblim, \nGarchomp, Lucario, Hippowdon,Abomasnow, Weavile, Magnezone,\nRhyperior, Tangrowth, Electivire, Magmortar,Dusknoir, Froslass,\nDialga, Palkia, Regigigas, Giratina, Arceus");
                        System.out.print("\n--------------------------------------------\n\n");
                        pokemonNumber--;
                        break;

                    default:

                        try {
                            pokemon = new Scanner(fpokemon);
                        }
                        catch (Exception e) {
                        }

                        dexRead = pokemon.next();
                        while(dexRead.compareTo("END") != 0){

                            if (dexRead.compareTo(userInput) == 0){

                                teams[team - 1][pokemonNumber - 1].pokemonSet(dexRead, pokemon);
                                dexRead = "END";
                                thatMonIsReal = true;

                            }
                            else{
                                dexRead = pokemon.next();
                            }


                        }
                        if (thatMonIsReal){
                            System.out.println("Pokemon Added! \n");
                            //teams[team - 1][pokemonNumber - 1].atoString();
                        }
                        else {
                            System.out.println("Pokemon Not Recognized.");
                            pokemonNumber--;
                        }
                        break;

                }

            }

        }



        for(int x = 0; x < 2; x++){
            System.out.println("\n\n\tTeam " + (x + 1) + ":");
            for (int y = 0; y <pokemonPerTeam; y++){
                teams[x][y].atoString();
                System.out.println();
            }
        }


        //Battle start
        while (numberOfRounds % 2 != 1) {
            System.out.println("How many rounds?");
            numberOfRounds = scan.nextInt();
        }

        while (numberOfRounds > 0){
            boolean selectedStart = false;
            for(int i = 0; i < 2; i++) {
                selectedStart = false;
                while (!selectedStart) {
                    System.out.println("Player " + (i + 1) + ", Select your starting pokemon: ");
                    switch (i) {
                        case 0:
                            activeMonT1 = scan.next();
                            for (int monsInTeamOne = 0; monsInTeamOne < pokemonPerTeam; monsInTeamOne++) {
                                if (activeMonT1.compareTo(teams[0][monsInTeamOne].name) == 0) {
                                    selectedStart = true;
                                    teams[0][monsInTeamOne].activeMon = true;
                                    teamOneActive = monsInTeamOne;
                                }
                            }
                            break;
                        case 1:
                            activeMonT2 = scan.next();
                            for (int monsInTeamTwo = 0; monsInTeamTwo < pokemonPerTeam; monsInTeamTwo++) {
                                if (activeMonT2.compareTo(teams[1][monsInTeamTwo].name) == 0) {
                                    selectedStart = true;
                                    teams[1][monsInTeamTwo].activeMon = true;
                                    teamTwoActive = monsInTeamTwo;
                                }
                            }
                            break;
                    }
                }
            }


            //LETS GET READY TO RRRRRRRRRRRRRRRRRRUMBLEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEEE
            livingMons1 = pokemonPerTeam;
            livingMons2 = pokemonPerTeam;
            trainer1switch = true;
            trainer2switch = true;
            System.out.println("Trainer 1 sent out " + teams[0][teamOneActive].name + "!");
            System.out.println("Trainer 2 sent out " + teams[1][teamTwoActive].name + "!");

            System.out.println(teams[0][teamOneActive].ability.compareTo("Mold_Breaker") == 0 ? ("Trainer 1's " + teams[0][teamOneActive].name + " breaks the mold!") : (""));
            System.out.println(teams[1][teamTwoActive].ability.compareTo("Mold_Breaker") == 0 ? ("Trainer 2's " + teams[1][teamTwoActive].name + " breaks the mold!") : (""));

            moldBreaker = (teams[0][teamOneActive].ability.compareTo("Mold_Breaker") == 0 || teams[1][teamTwoActive].ability.compareTo("Mold_Breaker") == 0);


            switch (teams[0][teamOneActive].ability) {
                case "Intimidate":
                    if (!moldBreaker) {
                        System.out.println("Trainer 1's " + teams[0][teamOneActive].name + "'s Intimidate drops the opposing " + teams[1][teamTwoActive].name + "'s attack!");
                        teams[1][teamTwoActive].statMods[0] -= .25;
                        if (teams[1][teamTwoActive].ability.compareTo("Hyper_Cutter") == 0) {
                            System.out.println("Trainer 2's " + teams[1][teamTwoActive].name + "'s Hyper Cutter protects it!");
                            teams[1][teamTwoActive].statMods[0] += .25;
                        }
                    }
                    break;
                case "Purified_Being":
                    System.out.println("You feel a sense of impending doom.");
                    break;
                case "Pressure":
                    if (!moldBreaker) {
                        System.out.println("Trainer 1's " + teams[0][teamOneActive].name + " Is exerting it's pressure!");
                    }
                    break;
                case "Sand_Stream":
                    System.out.println("Trainer 1's " + teams[0][teamOneActive].name + " kicked up a sandstorm!");
                    weather = Weather.sandstorm;
                    weatherTimer = rand.nextInt(5, 8);
                    break;
                case "Snow_Warning":
                    System.out.println("Trainer 1's " + teams[0][teamOneActive].name + " started a hailstorm!");
                    weather = Weather.halestorm;
                    weatherTimer = rand.nextInt(5, 8);
                    break;
                case "Slow_Start":
                    System.out.println("Trainer 1's " + teams[0][teamOneActive].name + " is warming up!");
                    teams[0][teamOneActive].slowStartTimer = 2;

                    break;
            }
            switch (teams[1][teamTwoActive].ability) {
                case "Intimidate":
                    if (!moldBreaker) {
                        System.out.println("Trainer 2's " + teams[1][teamTwoActive].name + "'s Intimidate drops the opposing " + teams[0][teamOneActive].name + "'s attack!");
                        teams[0][teamOneActive].statMods[0] -= .25;
                        if (teams[0][teamOneActive].ability.compareTo("Hyper_Cutter") == 0) {
                            System.out.println("Trainer 1's " + teams[0][teamOneActive].name + "'s Hyper Cutter protects it!");
                            teams[0][teamOneActive].statMods[0] += .25;
                        }
                    }
                    break;
                case "Purified_Being":
                    System.out.println("You feel a sense of impending doom.");
                    break;
                case "Pressure":
                    if (!moldBreaker) {
                        System.out.println("Trainer 2's " + teams[1][teamTwoActive].name + " Is exerting it's pressure!");
                    }
                    break;
                case "Sand_Stream":
                    System.out.println("Trainer 2's " + teams[1][teamTwoActive].name + " kicked up a sandstorm!");
                    weather = Weather.sandstorm;
                    weatherTimer = rand.nextInt(5, 8);
                    break;
                case "Snow_Warning":
                    System.out.println("Trainer 2's " + teams[1][teamTwoActive].name + " started a hailstorm!");
                    weather = Weather.halestorm;
                    weatherTimer = rand.nextInt(5, 8);
                    break;
                case "Slow_Start":
                    System.out.println("Trainer 2's " + teams[1][teamTwoActive].name + " is warming up!");
                    teams[1][teamTwoActive].slowStartTimer = 2;

                    break;
            }
            winCondition = false;
            trainer1NeedSwitch = false;
            trainer2NeedSwitch = false;
            while (!winCondition) {

                //ACTUAL BATTLE STUFFS
                trainerOneMove = -1;
                trainerTwoMove = -1;

                if (trainer1NeedSwitch){
                    switchableMon = false;
                    System.out.println("Pokemon: ");
                    for (int i = 0; i < pokemonPerTeam; i++){
                        System.out.println(teams[0][i].name +": " +teams[0][i].activeStats[0] + "/" + teams[0][i].activeStats[6] + " HP|");
                    }
                    while (!switchableMon){
                        System.out.println("\nEnter the mon you want to switch to.");
                        userInput = scan.next();


                            for (int i = 0; i < pokemonPerTeam; i++){
                                if (userInput.compareTo(teams[0][i].name) == 0 && teams[0][i].activeStats[0] > 0){
                                    if (i == teamOneActive){
                                        System.out.println("That pokemon is already in battle!");
                                    }
                                    else {
                                        System.out.println("Trainer 1 withdrew " + teams[0][teamOneActive].name);
                                        teamOneActive = i;
                                        switchableMon = true;

                                        System.out.println("Trainer 1 sent out " + teams[0][teamOneActive].name);
                                        if (moldBreaker == true && teams[1][teamTwoActive].ability.compareTo("Mold_Breaker") != 0 && teams[0][teamOneActive].ability.compareTo("Mold_Breaker") != 0){
                                            moldBreaker = false;
                                        }
                                        switch (teams[0][teamOneActive].ability) {
                                            case "Intimidate":
                                                if (!moldBreaker) {
                                                    System.out.println("Trainer 1's " + teams[0][teamOneActive].name + "'s Intimidate drops the opposing " + teams[1][teamTwoActive].name + "'s attack!");
                                                    teams[1][teamTwoActive].statMods[0] -= .25;
                                                    if (teams[1][teamTwoActive].ability.compareTo("Hyper_Cutter") == 0) {
                                                        System.out.println("Trainer 2's " + teams[1][teamTwoActive].name + "'s Hyper Cutter protects it!");
                                                        teams[1][teamTwoActive].statMods[0] += .25;
                                                    }
                                                }
                                                break;
                                            case "Purified_Being":
                                                System.out.println("You feel a sense of impending doom.");
                                                break;
                                            case "Pressure":
                                                if (!moldBreaker) {
                                                    System.out.println("Trainer 1's " + teams[0][teamOneActive].name + " Is exerting it's pressure!");
                                                }
                                                break;
                                            case "Sand_Stream":
                                                System.out.println("Trainer 1's " + teams[0][teamOneActive].name + " kicked up a sandstorm!");
                                                weather = Weather.sandstorm;
                                                weatherTimer = rand.nextInt(5, 8);
                                                break;
                                            case "Snow_Warning":
                                                System.out.println("Trainer 1's " + teams[0][teamOneActive].name + " started a hailstorm!");
                                                weather = Weather.halestorm;
                                                weatherTimer = rand.nextInt(5, 8);
                                                break;
                                            case "Slow_Start":
                                                System.out.println("Trainer 1's " + teams[0][teamOneActive].name + " is warming up!");
                                                teams[0][teamOneActive].slowStartTimer = 2;

                                                break;
                                            case "Mold_Breaker":
                                                moldBreaker = true;
                                                System.out.println(teams[0][teamOneActive].name + " breaks the mold!");
                                                break;
                                        }
                                    }
                                }
                            }

                    }
                }
                if (trainer2NeedSwitch){
                    switchableMon = false;
                    System.out.println("Pokemon: ");
                    for (int i = 0; i < pokemonPerTeam; i++){
                        System.out.println(teams[1][i].name +": " +teams[1][i].activeStats[0] + "/" + teams[1][i].activeStats[6] + " HP|");
                    }
                    while (!switchableMon){
                        System.out.println("\nEnter the mon you want to switch to ");
                        userInput = scan.next();



                            for (int i = 0; i < pokemonPerTeam; i++){
                                if (userInput.compareTo(teams[1][i].name) == 0 && teams[1][i].activeStats[0] > 0){
                                    if (i == teamTwoActive){
                                        System.out.println("That pokemon is already in battle!");
                                    }
                                    else {
                                        System.out.println("Trainer 2 withdrew " + teams[1][teamTwoActive].name);
                                        teamTwoActive = i;
                                        switchableMon = true;

                                        System.out.println("Trainer 2 sent out " + teams[1][teamTwoActive].name);
                                        if (moldBreaker == true && teams[1][teamTwoActive].ability.compareTo("Mold_Breaker") != 0 && teams[0][teamOneActive].ability.compareTo("Mold_Breaker") != 0){
                                            moldBreaker = false;
                                        }
                                        switch (teams[1][teamTwoActive].ability) {
                                            case "Intimidate":
                                                if (!moldBreaker) {
                                                    System.out.println("Trainer 2's " + teams[1][teamTwoActive].name + "'s Intimidate drops the opposing " + teams[0][teamOneActive].name + "'s attack!");
                                                    teams[0][teamOneActive].statMods[0] -= .25;
                                                    if (teams[0][teamOneActive].ability.compareTo("Hyper_Cutter") == 0) {
                                                        System.out.println("Trainer 1's " + teams[0][teamOneActive].name + "'s Hyper Cutter protects it!");
                                                        teams[0][teamOneActive].statMods[0] += .25;
                                                    }
                                                }
                                                break;
                                            case "Purified_Being":
                                                System.out.println("You feel a sense of impending doom.");
                                                break;
                                            case "Pressure":
                                                if (!moldBreaker) {
                                                    System.out.println("Trainer 2's " + teams[1][teamTwoActive].name + " Is exerting it's pressure!");
                                                }
                                                break;
                                            case "Sand_Stream":
                                                System.out.println("Trainer 2's " + teams[1][teamTwoActive].name + " kicked up a sandstorm!");
                                                weather = Weather.sandstorm;
                                                weatherTimer = rand.nextInt(5, 8);
                                                break;
                                            case "Snow_Warning":
                                                System.out.println("Trainer 2's " + teams[1][teamTwoActive].name + " started a hailstorm!");
                                                weather = Weather.halestorm;
                                                weatherTimer = rand.nextInt(5, 8);
                                                break;
                                            case "Slow_Start":
                                                System.out.println("Trainer 2's " + teams[1][teamTwoActive].name + " is warming up!");
                                                teams[1][teamTwoActive].slowStartTimer = 2;

                                                break;
                                        }
                                    }
                                }
                            }

                    }



                }

                trainerPickOrder = (teams[0][teamOneActive].activeStats[5] * teams[0][teamOneActive].statMods[6]) > (teams[1][teamTwoActive].activeStats[5] * teams[1][teamTwoActive].statMods[6]) ? 1 : (teams[0][teamOneActive].activeStats[5] * teams[0][teamOneActive].statMods[6]) == (teams[1][teamTwoActive].activeStats[5] * teams[1][teamTwoActive].statMods[6])? (rand.nextInt(0, 2) +1 ): 2;
                trainer1NeedSwitch = false;
                trainer2NeedSwitch = false;
                System.out.println("------------------------");
                if (trainerPickOrder == 1){

                    acceptedInput = false;
                    while (!acceptedInput) {
                        System.out.println("Trainer 1's Turn!\n-Fight\t-Switch");
                        userInput = scan.next();
                        switch (userInput) {
                            case "Fight":
                                acceptedMove = false;
                                while (!acceptedMove) {
                                    System.out.println("Select move number (\"Back\" to return): ");
                                    for (int i = 0; i < 2; i++) {
                                        System.out.println(((i * 2) + 1 + "| " + teams[0][teamOneActive].moves[((i * 2))] + " : " + ((i * 2) + 2) + "| " + teams[0][teamOneActive].moves[((i * 2) + 1)]));
                                    }
                                    userInput = scan.next();
                                    if (userInput.compareTo("Back") == 0) {
                                        acceptedMove = true;
                                    }
                                    else {
                                        try {
                                            trainerOneMove = Integer.parseInt(userInput);
                                            if (trainerOneMove > 0 && trainerOneMove < 5){
                                                acceptedMove = true;
                                                acceptedInput = true;
                                            }
                                        } catch (Exception e) {
                                        }
                                    }
                                }
                                break;
                            case "Switch":
                                switchableMon = false;
                                System.out.println("Pokemon: ");
                                for (int i = 0; i < pokemonPerTeam; i++){
                                    System.out.println(teams[0][i].name +": " +teams[0][i].activeStats[0] + "/" + teams[0][i].activeStats[6] + " HP|");
                                }
                                while (!switchableMon){
                                    System.out.println("\nEnter the mon you want to switch to (\"Back\" to return)");
                                    userInput = scan.next();

                                    if (userInput.compareTo("Back") == 0){
                                        switchableMon = true;
                                    }
                                    else{
                                        for (int i = 0; i < pokemonPerTeam; i++){
                                            if (userInput.compareTo(teams[0][i].name) == 0 && teams[0][i].activeStats[0] > 0){
                                                if (i == teamOneActive){
                                                    System.out.println("That pokemon is already in battle!");
                                                }
                                                else {
                                                    System.out.println("Trainer 1 withdrew " + teams[0][teamOneActive].name);
                                                    teamOneActive = i;
                                                    switchableMon = true;
                                                    acceptedInput = true;
                                                    System.out.println("Trainer 1 sent out " + teams[0][teamOneActive].name);
                                                    if (moldBreaker == true && teams[1][teamTwoActive].ability.compareTo("Mold_Breaker") != 0 && teams[0][teamOneActive].ability.compareTo("Mold_Breaker") != 0){
                                                        moldBreaker = false;
                                                    }
                                                    switch (teams[0][teamOneActive].ability) {
                                                        case "Intimidate":
                                                            if (!moldBreaker) {
                                                                System.out.println("Trainer 1's " + teams[0][teamOneActive].name + "'s Intimidate drops the opposing " + teams[1][teamTwoActive].name + "'s attack!");
                                                                teams[1][teamTwoActive].statMods[0] -= .25;
                                                                if (teams[1][teamTwoActive].ability.compareTo("Hyper_Cutter") == 0) {
                                                                    System.out.println("Trainer 2's " + teams[1][teamTwoActive].name + "'s Hyper Cutter protects it!");
                                                                    teams[1][teamTwoActive].statMods[0] += .25;
                                                                }
                                                            }
                                                            break;
                                                        case "Purified_Being":
                                                            System.out.println("You feel a sense of impending doom.");
                                                            break;
                                                        case "Pressure":
                                                            if (!moldBreaker) {
                                                                System.out.println("Trainer 1's " + teams[0][teamOneActive].name + " Is exerting it's pressure!");
                                                            }
                                                            break;
                                                        case "Sand_Stream":
                                                            System.out.println("Trainer 1's " + teams[0][teamOneActive].name + " kicked up a sandstorm!");
                                                            weather = Weather.sandstorm;
                                                            weatherTimer = rand.nextInt(5, 8);
                                                            break;
                                                        case "Snow_Warning":
                                                            System.out.println("Trainer 1's " + teams[0][teamOneActive].name + " started a hailstorm!");
                                                            weather = Weather.halestorm;
                                                            weatherTimer = rand.nextInt(5, 8);
                                                            break;
                                                        case "Slow_Start":
                                                            System.out.println("Trainer 1's " + teams[0][teamOneActive].name + " is warming up!");
                                                            teams[0][teamOneActive].slowStartTimer = 2;
                                                            teams[0][teamOneActive].statMods[0] = .5;
                                                            teams[0][teamOneActive].statMods[6] = .5;
                                                            break;
                                                        case "Mold_Breaker":
                                                            moldBreaker = true;
                                                            System.out.println(teams[0][teamOneActive].name + " breaks the mold!");
                                                            break;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                break;

                        }
                    }


                    acceptedInput = false;
                    while (!acceptedInput) {
                        System.out.println("Trainer 2's Turn!\n-Fight\t-Switch");
                        userInput = scan.next();
                        switch (userInput) {
                            case "Fight":
                                acceptedMove = false;
                                while (!acceptedMove) {
                                    System.out.println("Select move number (\"Back\" to return): ");
                                    for (int i = 0; i < 2; i++) {
                                        System.out.println(((i * 2) + 1 + "| " + teams[1][teamTwoActive].moves[((i * 2))] + " : " + ((i * 2) + 2) + "| " + teams[1][teamTwoActive].moves[((i * 2) + 1)]));
                                    }
                                    userInput = scan.next();
                                    if (userInput.compareTo("Back") == 0) {
                                        acceptedMove = true;
                                    } else {
                                        try {
                                            trainerTwoMove = Integer.parseInt(userInput);
                                            if (trainerTwoMove > 0 && trainerTwoMove < 5) {
                                                acceptedMove = true;
                                                acceptedInput = true;
                                            }
                                        } catch (Exception e) {
                                        }


                                    }
                                }
                                break;
                            case "Switch":
                                switchableMon = false;
                                System.out.println("Pokemon: ");
                                for (int i = 0; i < pokemonPerTeam; i++){
                                    System.out.println(teams[1][i].name +": " +teams[1][i].activeStats[0] + "/" + teams[1][i].activeStats[6] + " HP|");
                                }
                                while (!switchableMon){
                                    System.out.println("\nEnter the mon you want to switch to (\"Back\" to return)");
                                    userInput = scan.next();

                                    if (userInput.compareTo("Back") == 0){
                                        switchableMon = true;
                                    }
                                    else{
                                        for (int i = 0; i < pokemonPerTeam; i++){
                                            if (userInput.compareTo(teams[1][i].name) == 0 && teams[1][i].activeStats[0] > 0){
                                                if (i == teamTwoActive){
                                                    System.out.println("That pokemon is already in battle!");
                                                }
                                                else {
                                                    System.out.println("Trainer 2 withdrew " + teams[1][teamTwoActive].name);
                                                    teamTwoActive = i;
                                                    switchableMon = true;
                                                    acceptedInput = true;
                                                    System.out.println("Trainer 2 sent out " + teams[1][teamTwoActive].name);
                                                    if (moldBreaker == true && teams[1][teamTwoActive].ability.compareTo("Mold_Breaker") != 0 && teams[0][teamOneActive].ability.compareTo("Mold_Breaker") != 0){
                                                        moldBreaker = false;
                                                    }
                                                    switch (teams[1][teamTwoActive].ability) {
                                                        case "Intimidate":
                                                            if (!moldBreaker) {
                                                                System.out.println("Trainer 2's " + teams[1][teamTwoActive].name + "'s Intimidate drops the opposing " + teams[0][teamOneActive].name + "'s attack!");
                                                                teams[0][teamOneActive].statMods[0] -= .25;
                                                                if (teams[0][teamOneActive].ability.compareTo("Hyper_Cutter") == 0) {
                                                                    System.out.println("Trainer 1's " + teams[0][teamOneActive].name + "'s Hyper Cutter protects it!");
                                                                    teams[0][teamOneActive].statMods[0] += .25;
                                                                }
                                                            }
                                                            break;
                                                        case "Purified_Being":
                                                            System.out.println("You feel a sense of impending doom.");
                                                            break;
                                                        case "Pressure":
                                                            if (!moldBreaker) {
                                                                System.out.println("Trainer 2's " + teams[1][teamTwoActive].name + " Is exerting it's pressure!");
                                                            }
                                                            break;
                                                        case "Sand_Stream":
                                                            System.out.println("Trainer 2's " + teams[1][teamTwoActive].name + " kicked up a sandstorm!");
                                                            weather = Weather.sandstorm;
                                                            weatherTimer = rand.nextInt(5, 8);
                                                            break;
                                                        case "Snow_Warning":
                                                            System.out.println("Trainer 2's " + teams[1][teamTwoActive].name + " started a hailstorm!");
                                                            weather = Weather.halestorm;
                                                            weatherTimer = rand.nextInt(5, 8);
                                                            break;
                                                        case "Slow_Start":
                                                            System.out.println("Trainer 2's " + teams[1][teamTwoActive].name + " is warming up!");
                                                            teams[1][teamTwoActive].slowStartTimer = 2;
                                                            teams[1][teamTwoActive].statMods[0] = .5;
                                                            teams[1][teamTwoActive].statMods[6] = .5;
                                                            break;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                break;

                        }
                    }



                }
                else{

                    //trainer 2 start
                    acceptedInput = false;
                    while (!acceptedInput) {
                        System.out.println("Trainer 2's Turn!\n-Fight\t-Switch");
                        userInput = scan.next();
                        switch (userInput) {
                            case "Fight":

                                acceptedMove = false;
                                while (!acceptedMove) {
                                    System.out.println("Select move number (\"Back\" to return): ");
                                    for (int i = 0; i < 2; i++) {
                                        System.out.println(((i * 2) + 1 + "| " + teams[1][teamTwoActive].moves[((i * 2))] + " : " + ((i * 2) + 2) + "| " + teams[1][teamTwoActive].moves[((i * 2) + 1)]));
                                    }
                                    userInput = scan.next();
                                    if (userInput.compareTo("Back") == 0) {
                                        acceptedMove = true;
                                    }
                                    else {
                                        try {
                                            trainerTwoMove = Integer.parseInt(userInput);
                                            if (trainerTwoMove > 0 && trainerTwoMove < 5){
                                                acceptedMove = true;
                                                acceptedInput = true;
                                            }
                                        }
                                        catch (Exception e) {
                                        }
                                    }
                                }
                                break;
                            case "Switch":
                                switchableMon = false;
                                System.out.println("Pokemon: ");
                                for (int i = 0; i < pokemonPerTeam; i++){
                                    System.out.println(teams[1][i].name +": " +teams[1][i].activeStats[0] + "/" + teams[1][i].activeStats[6] + " HP|");
                                }
                                while (!switchableMon){
                                    System.out.println("\nEnter the mon you want to switch to (\"Back\" to return)");
                                    userInput = scan.next();

                                    if (userInput.compareTo("Back") == 0){
                                        switchableMon = true;
                                    }
                                    else{
                                        for (int i = 0; i < pokemonPerTeam; i++){
                                            if (userInput.compareTo(teams[1][i].name) == 0 && teams[1][i].activeStats[0] > 0){
                                                if (i == teamTwoActive){
                                                    System.out.println("That pokemon is already in battle!");
                                                }
                                                else {
                                                    System.out.println("Trainer 2 withdrew " + teams[1][teamTwoActive].name);
                                                    teamTwoActive = i;
                                                    switchableMon = true;
                                                    acceptedInput = true;
                                                    System.out.println("Trainer 2 sent out " + teams[1][teamTwoActive].name);
                                                    if (moldBreaker == true && teams[1][teamTwoActive].ability.compareTo("Mold_Breaker") != 0 && teams[0][teamOneActive].ability.compareTo("Mold_Breaker") != 0){
                                                        moldBreaker = false;
                                                    }
                                                    switch (teams[1][teamTwoActive].ability) {
                                                        case "Intimidate":
                                                            if (!moldBreaker) {
                                                                System.out.println("Trainer 2's " + teams[1][teamTwoActive].name + "'s Intimidate drops the opposing " + teams[0][teamOneActive].name + "'s attack!");
                                                                teams[0][teamOneActive].statMods[0] -= .25;
                                                                if (teams[0][teamOneActive].ability.compareTo("Hyper_Cutter") == 0) {
                                                                    System.out.println("Trainer 1's " + teams[0][teamOneActive].name + "'s Hyper Cutter protects it!");
                                                                    teams[0][teamOneActive].statMods[0] += .25;
                                                                }
                                                            }
                                                            break;
                                                        case "Purified_Being":
                                                            System.out.println("You feel a sense of impending doom.");
                                                            break;
                                                        case "Pressure":
                                                            if (!moldBreaker) {
                                                                System.out.println("Trainer 2's " + teams[1][teamTwoActive].name + " Is exerting it's pressure!");
                                                            }
                                                            break;
                                                        case "Sand_Stream":
                                                            System.out.println("Trainer 2's " + teams[1][teamTwoActive].name + " kicked up a sandstorm!");
                                                            weather = Weather.sandstorm;
                                                            weatherTimer = rand.nextInt(5, 8);
                                                            break;
                                                        case "Snow_Warning":
                                                            System.out.println("Trainer 2's " + teams[1][teamTwoActive].name + " started a hailstorm!");
                                                            weather = Weather.halestorm;
                                                            weatherTimer = rand.nextInt(5, 8);
                                                            break;
                                                        case "Slow_Start":
                                                            System.out.println("Trainer 2's " + teams[1][teamTwoActive].name + " is warming up!");
                                                            teams[1][teamTwoActive].slowStartTimer = 2;
                                                            teams[1][teamTwoActive].statMods[0] = .5;
                                                            teams[1][teamTwoActive].statMods[6] = .5;
                                                            break;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                break;

                        }
                    }


                    acceptedInput = false;
                    while (!acceptedInput) {
                        System.out.println("Trainer 1's Turn!\n-Fight\t-Switch");
                        userInput = scan.next();
                        switch (userInput) {
                            case "Fight":
                                acceptedMove = false;
                                while (!acceptedMove) {
                                    System.out.println("Select move number (\"Back\" to return): ");
                                    for (int i = 0; i < 2; i++) {
                                        System.out.println(((i * 2) + 1 + "| " + teams[0][teamOneActive].moves[((i * 2))] + " : " + ((i * 2) + 2) + "| " + teams[0][teamOneActive].moves[((i * 2) + 1)]));
                                    }
                                    userInput = scan.next();
                                    if (userInput.compareTo("Back") == 0) {
                                        acceptedMove = true;
                                    }
                                    else {
                                        try {
                                            trainerOneMove = Integer.parseInt(userInput);
                                            if (trainerOneMove > 0 && trainerOneMove < 5){
                                                acceptedMove = true;
                                                acceptedInput = true;
                                            }
                                        } catch (Exception e) {
                                        }
                                    }
                                }

                                break;
                            case "Switch":
                                switchableMon = false;
                                System.out.println("Pokemon: ");
                                for (int i = 0; i < pokemonPerTeam; i++){
                                    System.out.println(teams[0][i].name +": " +teams[0][i].activeStats[0] + "/" + teams[0][i].activeStats[6] + " HP|");
                                }
                                while (!switchableMon){
                                    System.out.println("\nEnter the mon you want to switch to (\"Back\" to return)");
                                    userInput = scan.next();

                                    if (userInput.compareTo("Back") == 0){
                                        switchableMon = true;
                                    }
                                    else{
                                        for (int i = 0; i < pokemonPerTeam; i++){
                                            if (userInput.compareTo(teams[0][i].name) == 0 && teams[0][i].activeStats[0] > 0){
                                                if (i == teamOneActive){
                                                    System.out.println("That pokemon is already in battle!");
                                                }
                                                else {
                                                    System.out.println("Trainer 1 withdrew " + teams[0][teamOneActive].name);
                                                    teamOneActive = i;
                                                    switchableMon = true;
                                                    acceptedInput = true;
                                                    System.out.println("Trainer 1 sent out " + teams[0][teamOneActive].name);
                                                    if (moldBreaker == true && teams[1][teamTwoActive].ability.compareTo("Mold_Breaker") != 0 && teams[0][teamOneActive].ability.compareTo("Mold_Breaker") != 0){
                                                        moldBreaker = false;
                                                    }
                                                    switch (teams[0][teamOneActive].ability) {
                                                        case "Intimidate":
                                                            if (!moldBreaker) {
                                                                System.out.println("Trainer 1's " + teams[0][teamOneActive].name + "'s Intimidate drops the opposing " + teams[1][teamTwoActive].name + "'s attack!");
                                                                teams[1][teamTwoActive].statMods[0] -= .25;
                                                                if (teams[1][teamTwoActive].ability.compareTo("Hyper_Cutter") == 0) {
                                                                    System.out.println("Trainer 2's " + teams[1][teamTwoActive].name + "'s Hyper Cutter protects it!");
                                                                    teams[1][teamTwoActive].statMods[0] += .25;
                                                                }
                                                            }
                                                            break;
                                                        case "Purified_Being":
                                                            System.out.println("You feel a sense of impending doom.");
                                                            break;
                                                        case "Pressure":
                                                            if (!moldBreaker) {
                                                                System.out.println("Trainer 1's " + teams[0][teamOneActive].name + " Is exerting it's pressure!");
                                                            }
                                                            break;
                                                        case "Sand_Stream":
                                                            System.out.println("Trainer 1's " + teams[0][teamOneActive].name + " kicked up a sandstorm!");
                                                            weather = Weather.sandstorm;
                                                            weatherTimer = rand.nextInt(5, 8);
                                                            break;
                                                        case "Snow_Warning":
                                                            System.out.println("Trainer 1's " + teams[0][teamOneActive].name + " started a hailstorm!");
                                                            weather = Weather.halestorm;
                                                            weatherTimer = rand.nextInt(5, 8);
                                                            break;
                                                        case "Slow_Start":
                                                            System.out.println("Trainer 1's " + teams[0][teamOneActive].name + " is warming up!");
                                                            teams[0][teamOneActive].slowStartTimer = 2;
                                                            teams[0][teamOneActive].statMods[0] = .5;
                                                            teams[0][teamOneActive].statMods[6] = .5;
                                                            break;
                                                        case "Mold_Breaker":
                                                            moldBreaker = true;
                                                            System.out.println(teams[0][teamOneActive].name + " breaks the mold!");
                                                            break;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                break;

                        }
                    }
                }


                try {
                    if (teams[1][teamTwoActive].moves[trainerTwoMove - 1].compareTo("Mach_Punch") == 0 || teams[1][teamTwoActive].moves[trainerTwoMove - 1].compareTo("Aqua_Jet") == 0 || teams[1][teamTwoActive].moves[trainerTwoMove - 1].compareTo("Quick_Attack") == 0 || teams[1][teamTwoActive].moves[trainerTwoMove - 1].compareTo("Shadow_Sneak") == 0 || teams[1][teamTwoActive].moves[trainerTwoMove - 1].compareTo("Bullet_Punch") == 0 || teams[1][teamTwoActive].moves[trainerTwoMove - 1].compareTo("Extreme_Speed") == 0 || teams[1][teamTwoActive].moves[trainerTwoMove - 1].compareTo("Ice_Shard") == 0) {
                        trainerPickOrder = 2;
                    } else if (teams[0][teamOneActive].moves[trainerOneMove - 1].compareTo("Mach_Punch") == 0 || teams[0][teamOneActive].moves[trainerOneMove - 1].compareTo("Aqua_Jet") == 0 || teams[0][teamOneActive].moves[trainerOneMove - 1].compareTo("Quick_Attack") == 0|| teams[0][teamOneActive].moves[trainerTwoMove - 1].compareTo("Shadow_Sneak") == 0 || teams[0][teamOneActive].moves[trainerTwoMove - 1].compareTo("Bullet_Punch") == 0 || teams[0][teamOneActive].moves[trainerTwoMove - 1].compareTo("Extreme_Speed") == 0|| teams[0][teamOneActive].moves[trainerTwoMove - 1].compareTo("Ice_Shard") == 0) {
                        trainerPickOrder = 1;
                    }
                }
                catch(Exception e){
                }

                if(trainerOneMove != -1){
                    if (trainerTwoMove == -1 || trainerPickOrder == 1){
                        System.out.println("Trainer 1's " + teams[0][teamOneActive].name + " used " + teams[0][teamOneActive].moves[trainerOneMove-1]);
                        if (Pokemon.getMoveAccuracy(teams[0][teamOneActive].moves[trainerOneMove -1], rand.nextInt(1, 101), teams[0][teamOneActive].statMods[4], teams[1][teamTwoActive].statMods[5])){
                            teams[0][teamOneActive].useMove((trainerOneMove-1) , 1, teamTwoActive, teams, rand.nextInt(1, 101), rand.nextInt(1, 101));

                        }
                        else{
                            System.out.println("But it missed!");
                        }
                        if (teams[1][teamTwoActive].activeStats[0] <= 0){
                            System.out.println(teams[1][teamTwoActive].name + " fainted!");
                            trainer2NeedSwitch = true;
                        }
                        if (teams[0][teamOneActive].activeStats[0] <= 0){
                            System.out.println(teams[0][teamOneActive].name + " fainted!");
                            trainer1NeedSwitch = true;
                        }
                        if (trainerTwoMove != -1 && !trainer2NeedSwitch) {
                            System.out.println("Trainer 2's " + teams[1][teamTwoActive].name + " used " + teams[1][teamTwoActive].moves[trainerTwoMove-1]);

                            if (!trainer1NeedSwitch) {
                                if (Pokemon.getMoveAccuracy(teams[1][teamTwoActive].moves[trainerTwoMove -1], rand.nextInt(1, 101), teams[1][teamTwoActive].statMods[4], teams[0][teamOneActive].statMods[5])) {
                                    teams[1][teamTwoActive].useMove((trainerTwoMove - 1), 0, teamOneActive, teams, rand.nextInt(1, 101), rand.nextInt(1, 101));
                                    if (teams[0][teamOneActive].activeStats[0] <= 0) {
                                        System.out.println(teams[0][teamOneActive].name + " fainted!");
                                        trainer1NeedSwitch = true;
                                    }
                                    if (teams[1][teamTwoActive].activeStats[0] <= 0) {
                                        System.out.println(teams[1][teamTwoActive].name + " fainted!");
                                        trainer2NeedSwitch = true;
                                    }
                                }
                                else{
                                    System.out.println("But it missed!");
                                }
                            }
                            else{
                                System.out.println("But there was no target!");
                            }
                        }
                    }
                    else{
                        System.out.println("Trainer 2's " + teams[1][teamTwoActive].name + " used " + teams[1][teamTwoActive].moves[trainerTwoMove-1]);
                        if (Pokemon.getMoveAccuracy(teams[1][teamTwoActive].moves[trainerTwoMove -1], rand.nextInt(1, 101), teams[1][teamTwoActive].statMods[4], teams[0][teamOneActive].statMods[5]))
                        {
                            teams[1][teamTwoActive].useMove((trainerTwoMove - 1), 0, teamOneActive, teams, rand.nextInt(1, 101), rand.nextInt(1, 101));
                            if (teams[0][teamOneActive].activeStats[0] <= 0) {
                                System.out.println(teams[0][teamOneActive].name + " fainted!");
                                trainer1NeedSwitch = true;
                            }
                            if (teams[1][teamTwoActive].activeStats[0] <= 0) {
                                System.out.println(teams[1][teamTwoActive].name + " fainted!");
                                trainer2NeedSwitch = true;
                            }
                        }
                        else{
                            System.out.println("But it missed!");
                        }
                        if (!trainer1NeedSwitch) {
                            System.out.println("Trainer 1's " + teams[0][teamOneActive].name + " used " + teams[0][teamOneActive].moves[trainerOneMove - 1]);
                            if (Pokemon.getMoveAccuracy(teams[0][teamOneActive].moves[trainerOneMove -1], rand.nextInt(1, 101), teams[0][teamOneActive].statMods[4], teams[1][teamTwoActive].statMods[5])) {
                                teams[0][teamOneActive].useMove((trainerOneMove - 1), 1, teamTwoActive, teams, rand.nextInt(1, 101), rand.nextInt(1, 101));
                                if (!trainer2NeedSwitch) {
                                    if (teams[1][teamTwoActive].activeStats[0] <= 0) {
                                        System.out.println(teams[1][teamTwoActive].name + " fainted!");
                                        trainer2NeedSwitch = true;
                                    }
                                }
                                else {
                                    System.out.println("But there was no target!");
                                }
                            }
                            else{
                                System.out.println("But it missed!");
                            }
                        }
                    }
                }
                else{
                    if (trainerTwoMove != -1) {
                        System.out.println("Trainer 2's " + teams[1][teamTwoActive].name + " used " + teams[1][teamTwoActive].moves[trainerTwoMove-1]);
                        teams[1][teamTwoActive].useMove((trainerTwoMove-1) , 0, teamOneActive, teams, rand.nextInt(1, 101), rand.nextInt(1, 101));

                        if (teams[0][teamOneActive].activeStats[0] <= 0){
                            System.out.println(teams[0][teamOneActive].name + " fainted!");
                            trainer1NeedSwitch = true;
                        }
                    }
                }


                if (teams[0][teamOneActive].item.compareTo("Berry") == 0){
                    if(((teams[0][teamOneActive].activeStats[0] / (double)teams[0][teamOneActive].activeStats[6]) < .33) && teams[0][teamOneActive].activeStats[0] != 0){
                        System.out.println(teams[0][teamOneActive].name + " used a berry!");
                        teams[0][teamOneActive].activeStats[0] += teams[0][teamOneActive].activeStats[6] / 4;
                        teams[0][teamOneActive].item = "NoItem";
                    }
                }
                if (teams[1][teamTwoActive].item.compareTo("Berry") == 0){
                    if(((teams[1][teamTwoActive].activeStats[0] / (double)teams[1][teamTwoActive].activeStats[6]) < .33) && teams[1][teamTwoActive].activeStats[0] != 0){
                        System.out.println(teams[1][teamTwoActive].name + " used a berry!");
                        teams[1][teamTwoActive].activeStats[0] += teams[1][teamTwoActive].activeStats[6] / 4;
                        teams[1][teamTwoActive].item = "NoItem";
                    }
                }



                //Weather penalty
                //Need add death check
                switch (weather) {
                    case sandstorm:
                        if (!(trainer1NeedSwitch || teams[0][teamOneActive].type1.compareTo("Rock") == 0 || teams[0][teamOneActive].type1.compareTo("Ground") == 0 || teams[0][teamOneActive].type1.compareTo("Steel") == 0 || teams[0][teamOneActive].type2.compareTo("Rock") == 0 || teams[0][teamOneActive].type2.compareTo("Ground") == 0 || teams[0][teamOneActive].type2.compareTo("Steel") == 0)) {
                            System.out.println("Trainer 1's " + teams[0][teamOneActive].name + " is hurt by the sandstorm!");
                            teams[0][teamOneActive].activeStats[0] -= teams[0][teamOneActive].activeStats[0] * (0.125);
                            System.out.println(teams[0][teamOneActive].activeStats[0] > 0 ? teams[0][teamOneActive].name + "'s health drops to " + teams[0][teamOneActive].activeStats[0] : teams[0][teamOneActive].name + " fainted!");
                            teams[0][teamOneActive].activeStats[0] = teams[0][teamOneActive].activeStats[0] > 0 ? teams[0][teamOneActive].activeStats[0] : 0;
                            trainer1NeedSwitch = teams[0][teamOneActive].activeStats[0] <= 0;

                        }
                        if (!(trainer2NeedSwitch || teams[1][teamTwoActive].type1.compareTo("Rock") == 0 || teams[1][teamTwoActive].type1.compareTo("Ground") == 0 || teams[1][teamTwoActive].type1.compareTo("Steel") == 0 || teams[1][teamTwoActive].type2.compareTo("Rock") == 0 || teams[1][teamTwoActive].type2.compareTo("Ground") == 0 || teams[1][teamTwoActive].type2.compareTo("Steel") == 0)) {
                            System.out.println("Trainer 2's " + teams[1][teamTwoActive].name + " is hurt by the sandstorm!");
                            teams[1][teamTwoActive].activeStats[0] -= teams[1][teamTwoActive].activeStats[0] * (0.125);
                            System.out.println(teams[1][teamTwoActive].activeStats[0] > 0 ? teams[1][teamTwoActive].name + "'s health drops to " + teams[1][teamTwoActive].activeStats[0] : teams[1][teamTwoActive].name + " fainted!");
                            teams[1][teamTwoActive].activeStats[0] = teams[1][teamTwoActive].activeStats[0] > 0 ? teams[1][teamTwoActive].activeStats[0] : 0;
                            trainer2NeedSwitch = teams[1][teamTwoActive].activeStats[0] <= 0;

                        }
                        weatherTimer--;
                        if (weatherTimer <= 0){
                            weather = Weather.clear;
                            System.out.println("The sandstorm subsided.");
                        }
                        break;
                    case halestorm:

                        if (!(trainer1NeedSwitch || teams[0][teamOneActive].type1.compareTo("Ice") == 0 || teams[0][teamOneActive].type2.compareTo("Ice") == 0)) {
                            System.out.println("Trainer 1's " + teams[0][teamOneActive].name + " is hurt by the hail!");
                            teams[0][teamOneActive].activeStats[0] -= teams[0][teamOneActive].activeStats[0] * (0.0625);
                            System.out.println(teams[0][teamOneActive].activeStats[0] > 0 ? teams[0][teamOneActive].name + "'s health drops to " + teams[0][teamOneActive].activeStats[0] : teams[0][teamOneActive].name + " fainted!");
                            teams[0][teamOneActive].activeStats[0] = teams[0][teamOneActive].activeStats[0] > 0 ? teams[0][teamOneActive].activeStats[0] : 0;
                            trainer1NeedSwitch = teams[0][teamOneActive].activeStats[0] <= 0;
                        }
                        if (!(trainer2NeedSwitch || teams[1][teamTwoActive].type1.compareTo("Ice") == 0 || teams[1][teamTwoActive].type2.compareTo("Ice") == 0)) {
                            System.out.println("Trainer 2's " + teams[1][teamTwoActive].name + " is hurt by the hail!");
                            teams[1][teamTwoActive].activeStats[0] -= teams[1][teamTwoActive].activeStats[0] * (0.0625);
                            System.out.println(teams[1][teamTwoActive].activeStats[0] > 0 ? teams[1][teamTwoActive].name + "'s health drops to " + teams[1][teamTwoActive].activeStats[0] : teams[1][teamTwoActive].name + " fainted!");
                            teams[1][teamTwoActive].activeStats[0] = teams[1][teamTwoActive].activeStats[0] > 0 ? teams[1][teamTwoActive].activeStats[0] : 0;
                            trainer2NeedSwitch = teams[1][teamTwoActive].activeStats[0] <= 0;
                        }
                        weatherTimer--;
                        if (weatherTimer <= 0){
                            weather = Weather.clear;
                            System.out.println("The hailstorm subsided.");
                        }
                        break;
                }

                if (teams[0][teamOneActive].item.compareTo("Berry") == 0){
                    if(((teams[0][teamOneActive].activeStats[0] / (double)teams[0][teamOneActive].activeStats[6]) < .33) && teams[0][teamOneActive].activeStats[0] != 0){
                        System.out.println(teams[0][teamOneActive].name + " used a berry!");
                        teams[0][teamOneActive].activeStats[0] += teams[0][teamOneActive].activeStats[6] / 4;
                        teams[0][teamOneActive].item = "NoItem";
                    }
                }
                if (teams[1][teamTwoActive].item.compareTo("Berry") == 0){
                    if(((teams[1][teamTwoActive].activeStats[0] / (double)teams[1][teamTwoActive].activeStats[6]) < .33) && teams[1][teamTwoActive].activeStats[0] != 0){
                        System.out.println(teams[1][teamTwoActive].name + " used a berry!");
                        teams[1][teamTwoActive].activeStats[0] += teams[1][teamTwoActive].activeStats[6] / 4;
                        teams[1][teamTwoActive].item = "NoItem";
                    }
                }
                if (teams[0][teamOneActive].item.compareTo("Leftovers")==0 && teams[0][teamOneActive].activeStats[0] != 0){
                    System.out.println(teams[0][teamOneActive].name + " healed from leftovers!");
                    teams[0][teamOneActive].activeStats[0] += (teams[0][teamOneActive].activeStats[6] / 16);
                }
                if (teams[1][teamTwoActive].item.compareTo("Leftovers")==0 && teams[1][teamTwoActive].activeStats[0] != 0){
                    System.out.println(teams[1][teamTwoActive].name + " healed from leftovers!");
                    teams[1][teamTwoActive].activeStats[0] += (teams[1][teamTwoActive].activeStats[6] / 16);
                }



                // check if battle is over
                livingMons1 = pokemonPerTeam;
                livingMons2 = pokemonPerTeam;
                for (int i = 0; i < pokemonPerTeam; i++){
                    if (teams[0][i].activeStats[0] <= 0){
                        livingMons1--;
                    }
                }
                if (livingMons1 == 0){
                    System.out.println("Trainer 1 is out of usable pokemon!\nTrainer 2 wins!");
                    winCondition = true;
                    for (int i = 0; i < pokemonPerTeam; i++){
                        teams[0][i].activeStats[0] = teams[0][i].activeStats[6];
                        teams[1][i].activeStats[0] = teams[1][i].activeStats[6];
                    }
                }
                for (int i = 0; i < pokemonPerTeam; i++){
                    if (teams[1][i].activeStats[0] <= 0){
                        livingMons2--;
                    }
                }
                if (livingMons2 == 0){
                    System.out.println("Trainer 2 is out of usable pokemon!\nTrainer 1 wins!");
                    winCondition = true;
                    for (int i = 0; i < pokemonPerTeam; i++){
                        teams[0][i].activeStats[0] = teams[0][i].activeStats[6];
                        teams[1][i].activeStats[0] = teams[1][i].activeStats[6];
                    }
                }



            }
            numberOfRounds--;

        }
        System.out.println("GGS!!");


    }
}


class Pokemon {

    public String name;
    public String item;
    public String ability;
    public String type1;
    public String type2;
    public String[] moves = new String[4];

    private int damage = 0;
    private int power= 0;
    public boolean activeMon = false;
    private boolean sturddi = false;
    public int[] stats = new int[6];
    // health, attack, defence, spatk, spDefence, speed

    public double[] statMods = new double[7];
    // attack, defence, spattack, spdef, accuracy, evasion, speed

    public int[] activeStats = new int[7];
    // + maxHp
    public int slowStartTimer = 0;

    public void useMove(int moveNum, int enemTeam, int enemActiveMon, Pokemon[][] teams, int critChanc, int roll){
        double effectiveness = 1;
        double boost = 1;
        if (this.item.compareTo("Life_Orb") == 0){
            boost += .3;
        }
        boolean crit = (critChanc > 95);
        switch(moves[moveNum]){
            case "Rock_Polish":

                if (statMods[6] != 4){
                    statMods[6] += 1;
                    System.out.println(this.name + "'s speed harshly increased!");
                }
                else{
                    System.out.println(this.name + "'s speed can't go any higher!");
                }
                break;
            case "Curse":

                if (statMods[6] != .25){
                    statMods[6] -= .25;
                    System.out.println(this.name + "'s speed fell!");
                }
                else{
                    System.out.println(this.name + "'s speed can't go any lower!");
                }
                if (statMods[0] != 4){
                    statMods[0] += .25;
                    System.out.println(this.name + "'s attack rose!");
                }
                else{
                    System.out.println(this.name + "'s attack can't go any higher!");
                }
                if (statMods[1] != 4){
                    statMods[1] += .25;
                    System.out.println(this.name + "'s defense rose!");
                }
                else{
                    System.out.println(this.name + "'s defense can't go any higher!");
                }
                break;
            case "Earthquake":
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Poison") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Poison") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Rock") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Rock") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Steel") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Steel") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Fire") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fire") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Electric") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Electric") == 0)){
                    effectiveness *= 2;
                }
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Bug") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Bug") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Grass") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Grass") == 0)){
                    effectiveness *= .5;
                }
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Flying") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Flying") == 0) || teams[enemTeam][enemActiveMon].ability.compareTo("Levitate") == 0){
                    effectiveness = 0;
                }
                //STAB
                if (this.type1.compareTo("Ground") == 0 || this.type2.compareTo("Ground") == 0){
                    boost += .5;
                }
                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, 100, crit, 1, boost);
                break;
            case "Earth_Power":
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Poison") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Poison") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Rock") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Rock") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Steel") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Steel") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Fire") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fire") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Electric") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Electric") == 0)){
                    effectiveness *= 2;
                }
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Bug") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Bug") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Grass") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Grass") == 0)){
                    effectiveness *= .5;
                }
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Flying") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Flying") == 0) || teams[enemTeam][enemActiveMon].ability.compareTo("Levitate") == 0){
                    effectiveness = 0;
                }
                //STAB
                if (this.type1.compareTo("Ground") == 0 || this.type2.compareTo("Ground") == 0){
                    boost += .5;
                }
                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, 80, crit, 2, boost);
                break;

            case "Sludge_Bomb":
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Grass") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Grass") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Fairy") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fairy") == 0) ){
                    effectiveness *= 2;
                }
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Poison") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Poison") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Ground") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ground") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Rock") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Rock") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Ghost") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ghost") == 0)   ){
                    effectiveness *= .5;
                }
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Steel") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Steel") == 0)  ){
                    effectiveness = 0;
                }
                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, 80, crit, 2, boost);
                break;


            case "Wood_Hammer":
                power = 120;
                if (((teams[enemTeam][enemActiveMon].type1.compareTo("Ground") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ground") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Rock") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Rock") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Water") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Water") == 0))){
                    effectiveness *= 2;
                }
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Flying") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Flying") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Poison") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Poison") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Bug") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Bug") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Steel") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Steel") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Fire") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fire") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Grass") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Grass") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Dragon") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Dragon") == 0)){
                    effectiveness *= .5;
                }
                if (this.type1.compareTo("Grass") == 0 || this.type2.compareTo("Grass") == 0){
                    boost += .5;
                }
                if (this.ability.compareTo("Overgrow") == 0 && (((double)this.activeStats[0] / this.activeStats[6]) <= .33)){
                    power = 180;
                }
                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, power, crit, 1, boost, true);
                break;


            case "Stone_Edge":
                crit = (critChanc > 90);
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Flying") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Flying") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Bug") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Bug") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Fire") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fire") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Ice") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ice") == 0)){
                    effectiveness *= 2;
                }
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Fighting") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fighting") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Ground") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ground") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Steel") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Steel") == 0)){
                    effectiveness *= .5;
                }
                if (this.type1.compareTo("Ground") == 0 || this.type2.compareTo("Ground") == 0){
                    boost += .5;
                }


                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, 100, crit, 1, boost);
                break;

            case "Rock_Slide":
                crit = (critChanc > 90);
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Flying") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Flying") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Bug") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Bug") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Fire") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fire") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Ice") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ice") == 0)){
                    effectiveness *= 2;
                }
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Fighting") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fighting") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Ground") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ground") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Steel") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Steel") == 0)){
                    effectiveness *= .5;
                }
                if (this.type1.compareTo("Ground") == 0 || this.type2.compareTo("Ground") == 0){
                    boost += .5;
                }


                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, 75, crit, 1, boost);
                break;

            case "Fire_Blast":
                power = 120;
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Bug") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Bug") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Steel") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Steel") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Grass") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Grass") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Ice") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ice") == 0) ){
                    effectiveness *= 2;
                }
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Rock") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Rock") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Fire") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fire") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Water") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Water") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Dragon") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Dragon") == 0)){
                    effectiveness *= .5;
                }
                if (this.type1.compareTo("Fire") == 0 || this.type2.compareTo("Fire") == 0){
                    boost += .5;
                }
                if (this.ability.compareTo("Blaze") == 0 && (((double)this.activeStats[0] / this.activeStats[6]) <= .33)){
                    power = 180;
                }
                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, power, crit, 2, boost);
                break;
            case "Flamethrower":
                power = 80;
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Bug") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Bug") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Steel") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Steel") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Grass") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Grass") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Ice") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ice") == 0) ){
                    effectiveness *= 2;
                }
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Rock") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Rock") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Fire") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fire") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Water") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Water") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Dragon") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Dragon") == 0)){
                    effectiveness *= .5;
                }
                if (this.type1.compareTo("Fire") == 0 || this.type2.compareTo("Fire") == 0){
                    boost += .5;
                }
                if (this.ability.compareTo("Blaze") == 0 && (((double)this.activeStats[0] / this.activeStats[6]) <= .33)){
                    power = 120;
                }
                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, power, crit, 2, boost);
                break;

            case "Fire_Punch":
                power = 75;
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Bug") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Bug") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Steel") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Steel") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Grass") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Grass") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Ice") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ice") == 0) ){
                    effectiveness *= 2;
                }
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Rock") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Rock") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Fire") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fire") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Water") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Water") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Dragon") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Dragon") == 0)){
                    effectiveness *= .5;
                }
                if (this.type1.compareTo("Fire") == 0 || this.type2.compareTo("Fire") == 0){
                    boost += .5;
                }
                if (this.ability.compareTo("Blaze") == 0 && (((double)this.activeStats[0] / this.activeStats[6]) <= .33)){
                    power = 100;
                }
                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, power, crit, 2, boost);
                break;

            case "Zen_Headbutt":
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Fighting") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fighting") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Poison") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Poison") == 0) ){
                    effectiveness *= 2;
                }
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Steel") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Steel") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Psychic") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Psychic") == 0)){
                    effectiveness *= .5;
                }
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Dark") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Dark") == 0) ){
                    effectiveness = 0;
                }
                if (this.type1.compareTo("Psychic") == 0 || this.type2.compareTo("Psychic") == 0){
                    boost += .5;
                }

                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, 80, crit, 1, boost);
                break;

            case "Hidden_Power_Fire":
                power = 60;
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Bug") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Bug") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Steel") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Steel") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Grass") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Grass") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Ice") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ice") == 0) ){
                    effectiveness *= 2;
                }
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Rock") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Rock") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Fire") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fire") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Water") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Water") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Dragon") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Dragon") == 0)){
                    effectiveness *= .5;
                }
                if (this.type1.compareTo("Fire") == 0 || this.type2.compareTo("Fire") == 0){
                    boost += .5;
                }
                if (this.ability.compareTo("Blaze") == 0 && (((double)this.activeStats[0] / this.activeStats[6]) <= .33)){
                    power = 90;
                }
                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, power, crit, 2, boost);
                break;


            case "Close_Combat":
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Normal") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Normal") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Rock") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Rock") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Steel") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Steel") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Ice") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ice") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Dark") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Dark") == 0) ){
                    effectiveness *= 2;
                }
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Bug") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Bug") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Flying") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Flying") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Poison") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Poison") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Fairy") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fairy") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Psychic") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Psychic") == 0) ){
                    effectiveness *= .5;
                }
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Ghost") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ghost") == 0) ){
                    effectiveness = 0;
                }
                if (this.type1.compareTo("Fighting") == 0 || this.type2.compareTo("Fighting") == 0){
                    boost += .5;
                }
                System.out.println("Dropped " + this.name + "'s Defense and Special Defense!");
                this.statMods[1] -= .25;
                if (this.statMods[1] < .25){
                    System.out.println(this.name + "'s Defense can't go any lower!");
                    this.statMods[1] = .25;
                }
                this.statMods[3] -= .25;
                if (this.statMods[3] < .25){
                    System.out.println(this.name + "'s Special Defense can't go any lower!");
                    this.statMods[3] = .25;
                }
                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, 120, crit, 1, boost);
                break;


            case "Mach_Punch":
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Normal") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Normal") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Rock") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Rock") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Steel") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Steel") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Ice") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ice") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Dark") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Dark") == 0) ){
                    effectiveness *= 2;
                }
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Bug") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Bug") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Flying") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Flying") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Poison") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Poison") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Fairy") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fairy") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Psychic") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Psychic") == 0) ){
                    effectiveness *= .5;
                }
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Ghost") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ghost") == 0) ){
                    effectiveness = 0;
                }
                if (this.type1.compareTo("Fighting") == 0 || this.type2.compareTo("Fighting") == 0){
                    boost += .5;
                }

                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, 40, crit, 1, boost);
                break;

            case "Low_Kick":
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Normal") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Normal") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Rock") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Rock") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Steel") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Steel") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Ice") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ice") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Dark") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Dark") == 0) ){
                    effectiveness *= 2;
                }
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Bug") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Bug") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Flying") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Flying") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Poison") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Poison") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Fairy") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fairy") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Psychic") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Psychic") == 0) ){
                    effectiveness *= .5;
                }
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Ghost") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ghost") == 0) ){
                    effectiveness = 0;
                }
                if (this.type1.compareTo("Fighting") == 0 || this.type2.compareTo("Fighting") == 0){
                    boost += .5;
                }

                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, 75, crit, 1, boost);
                break;


            case "Energy_Ball":
            case "Hidden_Power_Grass":
            case "Grass_Knot":
                power = 80;
                if (((teams[enemTeam][enemActiveMon].type1.compareTo("Ground") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ground") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Rock") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Rock") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Water") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Water") == 0))){
                    effectiveness *= 2;
                }
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Flying") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Flying") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Poison") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Poison") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Bug") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Bug") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Steel") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Steel") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Fire") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fire") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Grass") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Grass") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Dragon") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Dragon") == 0)){
                    effectiveness *= .5;
                }
                if (this.type1.compareTo("Grass") == 0 || this.type2.compareTo("Grass") == 0){
                    boost += .5;
                }
                if (this.ability.compareTo("Overgrow") == 0 && (((double)this.activeStats[0] / this.activeStats[6]) <= .33)){
                    power = 120;
                }
                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, power, crit, 2, boost);
                break;

            case "Power_Whip":
                power = 120;
                if (((teams[enemTeam][enemActiveMon].type1.compareTo("Ground") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ground") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Rock") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Rock") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Water") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Water") == 0))){
                    effectiveness *= 2;
                }
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Flying") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Flying") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Poison") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Poison") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Bug") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Bug") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Steel") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Steel") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Fire") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fire") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Grass") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Grass") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Dragon") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Dragon") == 0)){
                    effectiveness *= .5;
                }
                if (this.type1.compareTo("Grass") == 0 || this.type2.compareTo("Grass") == 0){
                    boost += .5;
                }
                if (this.ability.compareTo("Overgrow") == 0 && (((double)this.activeStats[0] / this.activeStats[6]) <= .33)){
                    power = 180;
                }
                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, power, crit, 2, boost);
                break;


            case "Flash_Cannon":
                if (((teams[enemTeam][enemActiveMon].type1.compareTo("Rock") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Rock") == 0) || ((teams[enemTeam][enemActiveMon].type1.compareTo("Ice") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ice") == 0) || ((teams[enemTeam][enemActiveMon].type1.compareTo("Fairy") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fairy") == 0))))){
                    effectiveness *= 2;
                }
                if (((teams[enemTeam][enemActiveMon].type1.compareTo("Steel") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Steel") == 0) || ((teams[enemTeam][enemActiveMon].type1.compareTo("Fire") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fire") == 0) || ((teams[enemTeam][enemActiveMon].type1.compareTo("Water") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Water") == 0) || ((teams[enemTeam][enemActiveMon].type1.compareTo("Electric") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Electric") == 0)))))){
                    effectiveness *= .5;
                }
                if (this.type1.compareTo("Steel") == 0 || this.type2.compareTo("Steel") == 0){
                    boost += .5;
                }
                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, 80, crit, 2, boost);
                break;


            case "Hydro_Pump":
                power = 120;
                if(((teams[enemTeam][enemActiveMon].type1.compareTo("Ground") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ground") == 0) || teams[enemTeam][enemActiveMon].type1.compareTo("Rock") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Rock") == 0) ||teams[enemTeam][enemActiveMon].type1.compareTo("Fire") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fire") == 0){
                    effectiveness *= 2;
                }
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Water") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Water") == 0)||(teams[enemTeam][enemActiveMon].type1.compareTo("Grass") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Grass") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Dragon") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Dragon") == 0)){
                    effectiveness *= .5;
                }
                if (this.type1.compareTo("Water") == 0 || this.type2.compareTo("Water") == 0){
                    boost += .5;
                }
                if (this.ability.compareTo("Torrent") == 0 && (((double)this.activeStats[0] / this.activeStats[6]) <= .33)){
                    power = 180;
                }
                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, power, crit, 2, boost);
                break;


            case "Ice_Beam":
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Ground") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ground") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Flying") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Flying") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Grass") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Grass") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Dragon") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Dragon") == 0) ){
                    effectiveness *= 2;
                }
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Steel") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Steel") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Fire") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fire") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Water") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Water") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Ice") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ice") == 0) ){
                    effectiveness *= .5;
                }
                if (this.type1.compareTo("Ice") == 0 || this.type2.compareTo("Ice") == 0){
                    boost += .5;
                }
                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, 80, crit, 2, boost);
                break;

            case "Blizzard":
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Ground") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ground") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Flying") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Flying") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Grass") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Grass") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Dragon") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Dragon") == 0) ){
                    effectiveness *= 2;
                }
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Steel") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Steel") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Fire") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fire") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Water") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Water") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Ice") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ice") == 0) ){
                    effectiveness *= .5;
                }
                if (this.type1.compareTo("Ice") == 0 || this.type2.compareTo("Ice") == 0){
                    boost += .5;
                }
                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, 100, crit, 2, boost);
                break;

            case "Hidden_Power_Ice":
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Ground") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ground") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Flying") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Flying") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Grass") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Grass") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Dragon") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Dragon") == 0) ){
                    effectiveness *= 2;
                }
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Steel") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Steel") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Fire") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fire") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Water") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Water") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Ice") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ice") == 0) ){
                    effectiveness *= .5;
                }
                if (this.type1.compareTo("Ice") == 0 || this.type2.compareTo("Ice") == 0){
                    boost += .5;
                }
                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, 60, crit, 2, boost);
                break;

            case "Ice_Punch":
            case "Ice_Shard":
            case "Ice_Fang":
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Ground") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ground") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Flying") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Flying") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Grass") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Grass") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Dragon") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Dragon") == 0) ){
                    effectiveness *= 2;
                }
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Steel") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Steel") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Fire") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fire") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Water") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Water") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Ice") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ice") == 0) ){
                    effectiveness *= .5;
                }
                if (this.type1.compareTo("Ice") == 0 || this.type2.compareTo("Ice") == 0){
                    boost += .5;
                }
                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, 65, crit, 2, boost);
                break;


            case "Aqua_Jet":
                if(((teams[enemTeam][enemActiveMon].type1.compareTo("Ground") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ground") == 0) || teams[enemTeam][enemActiveMon].type1.compareTo("Rock") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Rock") == 0) ||teams[enemTeam][enemActiveMon].type1.compareTo("Fire") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fire") == 0){
                    effectiveness *= 2;
                }
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Water") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Water") == 0)||(teams[enemTeam][enemActiveMon].type1.compareTo("Grass") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Grass") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Dragon") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Dragon") == 0)){
                    effectiveness *= .5;
                }
                if (this.type1.compareTo("Water") == 0 || this.type2.compareTo("Water") == 0){
                    boost += .5;
                }
                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, 40, crit, 1, boost);
                break;


            case "Brave_Bird":
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Fighting") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fighting") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Bug") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Bug") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Grass") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Grass") == 0)  ){
                    effectiveness *= 2;
                }
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Rock") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Rock") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Steel") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Steel") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Electic") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Electric") == 0)){
                    effectiveness *= .5;
                }
                if (this.type1.compareTo("Flying") == 0 || this.type2.compareTo("Flying") == 0){
                    boost += .5;
                }
                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, 120, crit, 1, boost, true);
                break;
            case "Aerial_Ace":
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Fighting") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fighting") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Bug") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Bug") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Grass") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Grass") == 0)  ){
                    effectiveness *= 2;
                }
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Rock") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Rock") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Steel") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Steel") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Electic") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Electric") == 0)){
                    effectiveness *= .5;
                }
                if (this.type1.compareTo("Flying") == 0 || this.type2.compareTo("Flying") == 0){
                    boost += .5;
                }
                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, 60, crit, 1, boost);
                break;
            case "Dragon_Claw":
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Dragon") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Dragon") == 0)){
                    effectiveness *= 2;
                }
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Steel") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Steel") == 0)){
                    effectiveness *= .5;
                }
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Fairy") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fairy") == 0)){
                    effectiveness = 0;
                }
                if (this.type1.compareTo("Dragon") == 0 || this.type2.compareTo("Dragon") == 0){
                    boost += .5;
                }
                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, 80, crit, 1, boost);
                break;
            case "Dragon_Pulse":
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Dragon") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Dragon") == 0)){
                    effectiveness *= 2;
                }
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Steel") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Steel") == 0)){
                    effectiveness *= .5;
                }
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Fairy") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fairy") == 0)){
                    effectiveness = 0;
                }
                if (this.type1.compareTo("Dragon") == 0 || this.type2.compareTo("Dragon") == 0){
                    boost += .5;
                }
                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, 80, crit, 2, boost);
                break;
            case "Spacial_Rend":
            case "Roar_Of_Time":
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Dragon") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Dragon") == 0)){
                    effectiveness *= 2;
                }
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Steel") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Steel") == 0)){
                    effectiveness *= .5;
                }
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Fairy") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fairy") == 0)){
                    effectiveness = 0;
                }
                if (this.type1.compareTo("Dragon") == 0 || this.type2.compareTo("Dragon") == 0){
                    boost += .5;
                }
                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, 110, crit, 2, boost);
                break;

            case "Indiscretion":
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Dragon") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Dragon") == 0)){
                    effectiveness *= 2;
                }
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Steel") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Steel") == 0)){
                    effectiveness *= .5;
                }
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Fairy") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fairy") == 0)){
                    effectiveness = 0;
                }
                if (this.type1.compareTo("Dragon") == 0 || this.type2.compareTo("Dragon") == 0){
                    boost += .5;
                }
                this.statMods[6] += .25;
                System.out.println("Giratina's speed increased!");
                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, 100, crit, 2, boost);
                break;


            case "Air_Cutter":
                crit = (critChanc > 90);
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Fighting") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fighting") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Bug") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Bug") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Grass") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Grass") == 0)  ){
                    effectiveness *= 2;
                }
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Rock") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Rock") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Steel") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Steel") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Electic") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Electric") == 0)){
                    effectiveness *= .5;
                }
                if (this.type1.compareTo("Flying") == 0 || this.type2.compareTo("Flying") == 0){
                    boost += .5;
                }
                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, 55, crit, 2, boost);
                break;
            case "Shadow_Ball":
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Ghost") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ghost") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Psychic") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Psychic") == 0) ){
                    effectiveness *= 2;
                }
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Dark") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Dark") == 0) ){
                    effectiveness *= .5;
                }
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Normal") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Normal") == 0) ){
                    effectiveness *= 0;
                }
                if (this.type1.compareTo("Ghost") == 0 || this.type2.compareTo("Ghost") == 0){
                    boost += .5;
                }
                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, 80, crit, 2, boost);
                break;

            case "Shadow_Sneak":
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Ghost") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ghost") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Psychic") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Psychic") == 0) ){
                    effectiveness *= 2;
                }
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Dark") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Dark") == 0) ){
                    effectiveness *= .5;
                }
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Normal") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Normal") == 0) ){
                    effectiveness *= 0;
                }
                if (this.type1.compareTo("Ghost") == 0 || this.type2.compareTo("Ghost") == 0){
                    boost += .5;
                }
                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, 40, crit, 1, boost);
                break;

            case "Shadow_Claw":
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Ghost") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ghost") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Psychic") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Psychic") == 0) ){
                    effectiveness *= 2;
                }
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Dark") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Dark") == 0) ){
                    effectiveness *= .5;
                }
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Normal") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Normal") == 0) ){
                    effectiveness *= 0;
                }
                if (this.type1.compareTo("Ghost") == 0 || this.type2.compareTo("Ghost") == 0){
                    boost += .5;
                }
                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, 80, crit, 1, boost);
                break;

            case "Double_Edge":
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Rock") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Rock") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Steel") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Steel") == 0)){
                    effectiveness *= .5;
                }
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Ghost") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ghost") == 0)){
                    effectiveness = 0;
                }
                if (this.type1.compareTo("Normal") == 0 || this.type2.compareTo("Normal") == 0){
                    boost += .5;
                }
                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, 120, crit, 1, boost, true);
                break;

            case "Extreme_Speed":
            case "Quick_Attack":
                if (moves[moveNum].compareTo("Extreme_Speed") == 0){
                    power = 80;
                }
                else{
                    power = 40;
                }
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Rock") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Rock") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Steel") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Steel") == 0)){
                    effectiveness *= .5;
                }
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Ghost") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ghost") == 0)){
                    effectiveness = 0;
                }
                if (this.type1.compareTo("Normal") == 0 || this.type2.compareTo("Normal") == 0){
                    boost += .5;
                }
                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, power, crit, 1, boost);
                break;

            case "Phantom_Force":
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Ghost") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ghost") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Psychic") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Psychic") == 0) ){
                    effectiveness *= 2;
                }
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Dark") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Dark") == 0) ){
                    effectiveness *= .5;
                }
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Normal") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Normal") == 0) ){
                    effectiveness *= 0;
                }
                if (this.type1.compareTo("Ghost") == 0 || this.type2.compareTo("Ghost") == 0){
                    boost += .5;
                }
                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, 120, crit, 1, boost);
                break;

            case "Waterfall":
                if(((teams[enemTeam][enemActiveMon].type1.compareTo("Ground") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ground") == 0) || teams[enemTeam][enemActiveMon].type1.compareTo("Rock") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Rock") == 0) ||teams[enemTeam][enemActiveMon].type1.compareTo("Fire") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fire") == 0){
                    effectiveness *= 2;
                }
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Water") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Water") == 0)||(teams[enemTeam][enemActiveMon].type1.compareTo("Grass") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Grass") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Dragon") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Dragon") == 0)){
                    effectiveness *= .5;
                }
                if (this.type1.compareTo("Water") == 0 || this.type2.compareTo("Water") == 0){
                    boost += .5;
                }
                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, 80, crit, 1, boost);
                break;

            case "Return":
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Rock") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Rock") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Steel") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Steel") == 0)){
                    effectiveness *= .5;
                }
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Ghost") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ghost") == 0)){
                    effectiveness = 0;
                }
                if (this.type1.compareTo("Normal") == 0 || this.type2.compareTo("Normal") == 0){
                    boost += .5;
                }
                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, 102, crit, 1, boost);
                break;

            case "Forfeit_All_Mortal_Possesions":
                //Context: I love wooper. Wooper, the silly little pokemon, is my absolute favorite. A few years ago, I started actively searching for any and all images of wooper, and amassed a *decent* amount
                //(The amount was well over 500 images. of just the goofy little lad)
                //My friends joked that i had begun worshipping wooper, and thus the Cult of Wooper was created.
                //thus, since this is *my* creation, i dont see any reason why Biblically Accurate Wooper cannot exist.
                //卅(◕‿◕)卅
                //⬜⬜⬜⬛⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜
                //⬜⬜⬛🟪⬛⬜⬛⬛⬛⬛⬛⬛⬜⬜⬜⬜⬜⬜⬜⬜
                //⬜⬛⬛🟪⬛⬛🟦🟦🟦🟦🟦🟦⬛⬛⬜⬜⬜⬜⬜⬜
                //⬛🟪🟪🟪⬛🟦🟦🟦🟦🟦🟦🟦🟦🟦⬛⬜⬜⬜⬜⬜
                //⬜⬛🟪⬛🟦⬛🟦🟦🟦🟦🟦🟦🟦🟦🟦⬛⬜⬜⬜⬜
                //⬜⬛🟪⬛🟦🟦🟦🟦🟦🟦🟦🟦🟦🟦⬛🟪⬛⬜⬜⬜
                //⬜⬜⬛⬛🟦🟦🟦🟦🟦⬛🟦🟦🟦⬛⬛🟪⬛⬛⬜⬜
                //⬜⬜⬜⬛🟦⬛⬛🟦🟦🟦🟦⬛🟦🟪🟪🟪⬛🟪⬛⬜
                //⬜⬜⬜⬜⬛🟦🟦⬛⬛⬛⬛🟦🟦⬛🟪🟪🟪🟪⬛⬜
                //⬜⬜⬜⬜⬜⬛⬛🟦🟦🟦🟦🟦⬛⬛🟪⬛🟪🟪🟪⬛
                //⬜⬜⬜⬜⬜⬜⬜⬛⬛⬛⬛⬛⬜⬜⬛⬛🟪⬛⬛⬜
                //⬜⬜⬜⬜⬜⬜⬜⬛⬛🟦⬛⬜⬜⬛⬛⬜⬛⬜⬜⬜
                //⬜⬜⬜⬜⬜⬜⬛⬛🟦🟦🟦⬛⬛🟦🟦⬛⬜⬜⬜⬜
                //⬜⬜⬜⬜⬜⬛🟦🟦⬛⬛🟦⬛🟦🟦🟦⬛⬜⬜⬜⬜
                //⬜⬜⬜⬜⬜⬜⬛⬛🟦🟦⬛⬛⬛⬛⬛⬜⬜⬜⬜⬜
                //⬜⬜⬜⬜⬜⬜⬜⬜⬛⬛🟦🟦⬛⬜⬜⬜⬜⬜⬜⬜
                //⬜⬜⬜⬜⬜⬜⬜⬜⬜⬜⬛⬛⬜⬜⬜⬜⬜⬜⬜⬜
                System.out.println("A̸͈̎n̵̩͒d̷̼̓ ̸̠̆w̴͚̽h̸̡̅ā̸̱ṯ̴̐ ̴͕̈́f̸̝̊o̸͔͠u̷͓͛l̴͉̉ ̵̦̒b̴̝̑ę̵̊a̵̖̓s̷͙͐t̷̗͌,̴̦͆ ̴̦͐i̸̙̊ť̵̥s̵̩̑ ̶̳̕ḧ̵͔́ò̴̲u̶͕̎ṛ̴͊ ̵̦̉c̵̜̾ő̷͔m̴̻̎ë̷͍ ̸̟͌r̴͓͐o̴͔̓ű̴̖n̷̠̎d̸̓͜ ̶̟̈à̵̯t̷̝̍ ̴͓͛l̸͙̚a̸̘͛s̵͙̆t̷̯̓,̸̳͘ ̸̰́s̷͙̚ĺ̵̞ö̸̻ǘ̴̺c̶̽͜h̵͉͝ë̸͈s̷̗͗ ̵̖̌t̵͉͝o̴̭͌w̵͈̔ä̸̤́r̵̳̈́d̶͉̑š̴͎ ̴̛̖B̸̢͋é̴̡t̴̲̊h̶̦̏l̶̂͜e̸̡͘h̴̙͘ě̵͖m̴̺̒ ̸̫͝t̷̨͝ǫ̴͂ ̷̝͊b̸̻͆ë̷̥́ ̵͓̓b̷̲̔ò̸̩r̴͉̀n̶̪͌?̸͙̓");
                for(int i = 0; i <7; i++){
                    this.statMods[i] = 10;
                }
                break;
            case "Woop":
                System.out.println("Ṱ̵̀h̵͓͗e̴̺̚ ̵͎́b̴̠̒ĕ̷̤l̶͚̓l̴͓̀s̵̤̈́ ̸̻̇t̷̟͘o̷͓͠l̴̬̅l̸͇̔ ̵̗͛ö̶́͜n̴̡̿ĉ̵̬e̴̩̽.̷̨̋");
                damageCalc(enemTeam, enemActiveMon,teams, 100, 9999999, true, 1, 800);
                break;
            case "Wooper's_Divine_Blessing":
                System.out.println("L̴̲̀ḭ̸͆f̴̺͋e̶̢͒ ̶̙̾i̴̺̔ț̵͊s̷͕̆e̵͖̐ļ̴͊f̷͇̓ ̴̰̾i̶̺̔s̴͖̊ ̷̱̊b̵̺̈́u̴̡͆t̸̙̅ ̷̙̓t̶͈̾h̶̞̓e̵̞͛ ̶̨̑s̸̺̿h̸̔ͅa̵̘̔ḓ̴͑o̷̻̿w̴̞̽ ̶̝̒o̴̝̊f̸̜͘ ̵̘̈́d̸̖̑ẹ̵̈́ä̶̮́t̴͕̕ḧ̵̨,̵̣͛ ̶̨̈́á̷̝n̵̪̈́d̴̦̕ ̵͇̑s̷͇̅o̴͉͂u̴͎̎l̸̩̋ś̶̰ ̵̜͝d̷̘̆e̶̛̟ṗ̷̠a̵͐ͅṛ̸͊t̷̟͂e̴̒ͅd̶͇̋ ̶̖̍b̷͊͜u̵͈͠t̴͈̂ ̵͈́t̶͇̋h̴̝͝e̴̠͌ ̷̦̇s̶̮̈h̸̳͒ā̷̻ď̴͔o̸̭̾w̸̥̓s̶̝̀ ̵̥̋o̸̘̐f̵͎̃ ̵̣̎t̸̻͑h̵̼͗ė̷͔ ̸̯̏ĺ̴̼i̵͕͐v̶̛͉i̷̪̎n̶͔̚g̷͈̕");
                this.stats[0] = 999999999;
                break;
            case "True_Face_Of_God":
                System.out.println("A warmth fills your chest. You are finally at peace.");
                for(int i = 0; i < 8; i++){
                    try{
                        teams[enemTeam][i].activeStats[0] = 0;
                        System.out.println("A rejector has been e̸x̷t̴i̸n̶g̸u̷i̶s̴h̶e̵d̷.");
                    }
                    catch (Exception e){
                        System.out.println("\"Then the angel showed me the river of the water of life, as clear as crystal, flowing from the Lord's throne\ndown the middle of the great street of the city. on each side of the river stood the tree of life, bearing twelve crops of fruit, yielding its fruit every month. and the leaves of the tree are for the healing of the nations. \n no longer will there be any curse. the throne of the Lord will be in the city, and its servants will serve it. \n they will see its face, and its name will be on their foreheads. \n there will be no more night. they will not need the light of the sun any longer.\"");
                        i = 10;
                    }
                }
                break;
            case "Swords_Dance":
                System.out.println(this.name + "'s Attack drastically rose!");
                this.statMods[0] += 1;
                if (this.statMods[0] > 4){
                    System.out.println(this.name + "'s attack can't go any higher!");
                    this.statMods[0] = 4;
                }
                break;

            case "Calm_Mind":
                System.out.println(this.name + "'s Special Attack rose!");
                this.statMods[2] += .5;
                if (this.statMods[2] > 4){
                    System.out.println(this.name + "'s special attack can't go any higher!");
                    this.statMods[2] = 4;
                }
                this.statMods[3] += .5;
                System.out.println(this.name + "'s Special Defense rose!");
                if (this.statMods[3] > 4){
                    System.out.println(this.name + "'s special defense can't go any higher!");
                    this.statMods[3] = 4;
                }
                break;

            case "Iron_Head":
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Rock") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Rock") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Ice") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ice") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Fairy") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fairy") == 0)  ){
                    effectiveness *= 2;
                }
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Steel") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Steel") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Fire") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fire") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Water") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Water") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Electric") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Electric") == 0)){
                    effectiveness *= .5;
                }
                if (this.type1.compareTo("Steel") == 0 || this.type2.compareTo("Steel") == 0){
                    boost += .5;
                }
                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, 80, crit, 1, boost);
                break;

            case "Bullet_Punch":
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Rock") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Rock") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Ice") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ice") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Fairy") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fairy") == 0)  ){
                    effectiveness *= 2;
                }
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Steel") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Steel") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Fire") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fire") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Water") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Water") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Electric") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Electric") == 0)){
                    effectiveness *= .5;
                }
                if (this.type1.compareTo("Steel") == 0 || this.type2.compareTo("Steel") == 0){
                    boost += .5;
                }
                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, 40, crit, 1, boost);
                break;

            case "X_Scissor":
                power = 80;
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Grass") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Grass") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Psychic") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Psychic") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Dark") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Dark") == 0)){
                    effectiveness *= 2;
                }
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Fighting") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fighting") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Flying") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Flying") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Poison") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Poison") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Ghost") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ghost") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Steel") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Steel") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Fire") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fire") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Fairy") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fairy") == 0)){
                    effectiveness *= .5;
                }
                if (this.type1.compareTo("Bug") == 0 || this.type2.compareTo("Bug") == 0){
                    boost += .5;
                }
                if (this.ability.compareTo("Swarm") == 0 && (((double)this.activeStats[0] / this.activeStats[6]) <= .33)){
                    power = 120;
                }
                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, power, crit, 1, boost);
                break;

            case "Megahorn":
                power = 120;
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Grass") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Grass") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Psychic") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Psychic") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Dark") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Dark") == 0)){
                    effectiveness *= 2;
                }
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Fighting") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fighting") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Flying") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Flying") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Poison") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Poison") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Ghost") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ghost") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Steel") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Steel") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Fire") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fire") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Fairy") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fairy") == 0)){
                    effectiveness *= .5;
                }
                if (this.type1.compareTo("Bug") == 0 || this.type2.compareTo("Bug") == 0){
                    boost += .5;
                }
                if (this.ability.compareTo("Swarm") == 0 && (((double)this.activeStats[0] / this.activeStats[6]) <= .33)){
                    power = 180;
                }
                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, power, crit, 1, boost);
                break;

            case "Attack_Order":
                crit = (critChanc > 85);
                power = 90;
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Grass") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Grass") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Psychic") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Psychic") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Dark") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Dark") == 0)){
                    effectiveness *= 2;
                }
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Fighting") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fighting") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Flying") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Flying") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Poison") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Poison") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Ghost") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ghost") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Steel") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Steel") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Fire") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fire") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Fairy") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fairy") == 0)){
                    effectiveness *= .5;
                }
                if (this.type1.compareTo("Bug") == 0 || this.type2.compareTo("Bug") == 0){
                    boost += .5;
                }
                if (this.ability.compareTo("Swarm") == 0 && (((double)this.activeStats[0] / this.activeStats[6]) <= .33)){
                    power = 130;
                }
                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, power, crit, 1, boost);
                break;

            case "Recover":
            case "Synthesis":
            case "Slack_Off":
            case "Roost":
                this.activeStats[0] += this.activeStats[6] / 2;
                break;

            case "Brick_Break":
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Normal") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Normal") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Rock") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Rock") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Steel") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Steel") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Ice") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ice") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Dark") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Dark") == 0) ){
                    effectiveness *= 2;
                }
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Bug") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Bug") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Flying") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Flying") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Poison") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Poison") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Fairy") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fairy") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Psychic") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Psychic") == 0) ){
                    effectiveness *= .5;
                }
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Ghost") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ghost") == 0) ){
                    effectiveness = 0;
                }
                if (this.type1.compareTo("Fighting") == 0 || this.type2.compareTo("Fighting") == 0){
                    boost += .5;
                }

                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, 75, crit, 1, boost);
                break;

            case "Night_Slash":
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Ghost") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ghost") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Psychic") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Psychic") == 0)){
                    effectiveness *= 2;
                }
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Fighting") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fighting") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Dark") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Dark") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Fairy") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fairy") == 0)){
                    effectiveness *= .5;
                }
                if (this.type1.compareTo("Dark") == 0 || this.type2.compareTo("Dark") == 0){
                    boost += .5;
                }
                crit = (critChanc > 70);
                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, 70, crit, 1, boost);
                break;

            case "Crunch":
                if((teams[enemTeam][enemActiveMon].type1.compareTo("Ghost") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ghost") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Psychic") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Psychic") == 0)){
                    effectiveness *= 2;
                }
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Fighting") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fighting") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Dark") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Dark") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Fairy") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fairy") == 0)){
                    effectiveness *= .5;
                }
                if (this.type1.compareTo("Dark") == 0 || this.type2.compareTo("Dark") == 0){
                    boost += .5;
                }
                crit = (critChanc > 70);
                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, 80, crit, 1, boost);
                break;

            case "High_Voltage":
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Flying") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Flying") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Water") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Water") == 0)){
                    effectiveness *= 2;
                }
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Grass") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Grass") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Electric") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Electric") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Dragon") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Dragon") == 0)){
                    effectiveness *= .5;
                }
                if (this.type1.compareTo("Electric") == 0 || this.type2.compareTo("Electric") == 0){
                    boost += .5;
                }
                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, 85, crit, 1, boost);
                break;
            case "Thunder_Punch":
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Flying") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Flying") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Water") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Water") == 0)){
                    effectiveness *= 2;
                }
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Grass") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Grass") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Electric") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Electric") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Dragon") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Dragon") == 0)){
                    effectiveness *= .5;
                }
                if (this.type1.compareTo("Electric") == 0 || this.type2.compareTo("Electric") == 0){
                    boost += .5;
                }
                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, 75, crit, 1, boost);
                break;

            case "Thunderbolt":
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Flying") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Flying") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Water") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Water") == 0)){
                    effectiveness *= 2;
                }
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Grass") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Grass") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Electric") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Electric") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Dragon") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Dragon") == 0)){
                    effectiveness *= .5;
                }
                if (this.type1.compareTo("Electric") == 0 || this.type2.compareTo("Electric") == 0){
                    boost += .5;
                }
                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, 95, crit, 2, boost);
                break;

            case "Superpower":
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Normal") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Normal") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Rock") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Rock") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Steel") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Steel") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Ice") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ice") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Dark") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Dark") == 0) ){
                    effectiveness *= 2;
                }
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Bug") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Bug") == 0) || (teams[enemTeam][enemActiveMon].type1.compareTo("Flying") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Flying") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Poison") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Poison") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Fairy") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Fairy") == 0) ||(teams[enemTeam][enemActiveMon].type1.compareTo("Psychic") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Psychic") == 0) ){
                    effectiveness *= .5;
                }
                if ((teams[enemTeam][enemActiveMon].type1.compareTo("Ghost") == 0 || teams[enemTeam][enemActiveMon].type2.compareTo("Ghost") == 0) ){
                    effectiveness = 0;
                }
                if (this.type1.compareTo("Fighting") == 0 || this.type2.compareTo("Fighting") == 0){
                    boost += .5;
                }
                System.out.println("Dropped " + this.name + "'s Attack and Defense!");
                this.statMods[1] -= .25;
                if (this.statMods[1] < .25){
                    System.out.println(this.name + "'s Defense can't go any lower!");
                    this.statMods[1] = .25;
                }
                this.statMods[0] -= .25;
                if (this.statMods[0] < .25){
                    System.out.println(this.name + "'s Attack can't go any lower!");
                    this.statMods[0] = .25;
                }
                damageCalc(enemTeam, enemActiveMon, teams, effectiveness, 120, crit, 1, boost);
                break;

        }
    }

    public void damageCalc(int enemTeam, int enemActiveMon, Pokemon[][] teams, double effectiveness,  int power, boolean crit, int physSpec, double boost) {
        if (effectiveness > 1 || teams[enemTeam][enemActiveMon].ability.compareTo("Solid_Rock") == 0){
            effectiveness *= .75;
        }
        damage = 0;
        damage = (int)(((22) * power * ((this.stats[physSpec == 1? 1: 3] * (teams[enemTeam][enemActiveMon].ability.compareTo("Unaware") == 0 ? 1 :this.statMods[physSpec == 1? 0: 2])) / ((teams[enemTeam][enemActiveMon].stats[physSpec == 1? 2: 4] * (this.ability.compareTo("Unaware") == 0 ? 1: teams[enemTeam][enemActiveMon].statMods[physSpec == 1? 1: 3])))) / 50) * (crit ? 2 : 1) * boost * effectiveness);
        if (effectiveness > 1 && this.item.compareTo("Expert_Belt") == 0){
            damage *= 1.3;
        }
        if (teams[enemTeam][enemActiveMon].stats[0] == teams[enemTeam][enemActiveMon].activeStats[6] && damage >= teams[enemTeam][enemActiveMon].activeStats[6] && teams[enemTeam][enemActiveMon].ability.compareTo("Sturdy") == 0){
            System.out.println(teams[enemTeam][enemActiveMon].name + " hung on!");
            sturddi = true;
        }
        teams[enemTeam][enemActiveMon].activeStats[0] -= damage;
        teams[enemTeam][enemActiveMon].activeStats[0] = teams[enemTeam][enemActiveMon].activeStats[0] < 0 ? 0 :teams[enemTeam][enemActiveMon].activeStats[0];
        if (crit){
            System.out.println("Critical hit!");
        }
        System.out.println(effectiveness != 1 ? effectiveness > 1 ? "It's super effective!" : (effectiveness == 0 ? "It has no effect!" : "It's not very effective...") : "-");
        if (sturddi){
            teams[enemTeam][enemActiveMon].activeStats[0] = 1;
            sturddi = false;
        }
        System.out.println(teams[enemTeam][enemActiveMon].name +": " +teams[enemTeam][enemActiveMon].activeStats[0] + "/" + teams[enemTeam][enemActiveMon].activeStats[6]);
        if (teams[enemTeam][enemActiveMon].ability.compareTo("Thorny") ==0 && physSpec == 1){
            System.out.println(this.name + " was hurt!");
            this.activeStats[0] -= this.activeStats[0] / 16;
            this.activeStats[0] = this.activeStats[0] < 0 ? 0 :this.activeStats[0];
            System.out.println(this.name +": " +this.activeStats[0] + "/" + this.activeStats[6]);
        }

    }

    public void damageCalc(int enemTeam, int enemActiveMon, Pokemon[][] teams, double effectiveness,  int power, boolean crit, int physSpec, double boost, boolean recoil) {
        damage = 0;
        if (effectiveness > 1 || teams[enemTeam][enemActiveMon].ability.compareTo("Solid_Rock") == 0){
            effectiveness *= .75;
        }
        damage = (int)(((22) * power * ((this.stats[physSpec == 1? 1: 3] * (teams[enemTeam][enemActiveMon].ability.compareTo("Unaware") == 0 ? 1 :this.statMods[physSpec == 1? 0: 2])) / ((teams[enemTeam][enemActiveMon].stats[physSpec == 1? 2: 4] * (this.ability.compareTo("Unaware") == 0 ? 1: teams[enemTeam][enemActiveMon].statMods[physSpec == 1? 1: 3])))) / 50) * (crit ? 2 : 1) * boost * effectiveness);
        if (effectiveness > 1 && this.item.compareTo("Expert_Belt") == 0){
            damage *= 1.3;
        }
        teams[enemTeam][enemActiveMon].activeStats[0] -= damage;

        if (teams[enemTeam][enemActiveMon].stats[0] == teams[enemTeam][enemActiveMon].activeStats[6] && damage >= teams[enemTeam][enemActiveMon].activeStats[6] && teams[enemTeam][enemActiveMon].ability.compareTo("Sturdy") == 0){
            System.out.println(teams[enemTeam][enemActiveMon].name + " hung on!");
            sturddi = true;
        }
        teams[enemTeam][enemActiveMon].activeStats[0] = teams[enemTeam][enemActiveMon].activeStats[0] < 0 ? 0 :teams[enemTeam][enemActiveMon].activeStats[0];
        if (crit){
            System.out.println("Critical hit!");
        }
        System.out.println(effectiveness != 1 ? effectiveness > 1 ? "It's super effective!" : (effectiveness == 0 ? "It has no effect!" : "It's not very effective...") : "-");
        if (sturddi){
            teams[enemTeam][enemActiveMon].activeStats[0] = 1;
            sturddi = false;
        }
        System.out.println(teams[enemTeam][enemActiveMon].name +": " +teams[enemTeam][enemActiveMon].activeStats[0] + "/" + teams[enemTeam][enemActiveMon].activeStats[6]);
        this.activeStats[0] -= (damage/3);
        System.out.println(this.name + " took recoil!");
        this.activeStats[0] = this.activeStats[0] < 0 ? 0 :this.activeStats[0];
        System.out.println(this.name +": " +this.activeStats[0] + "/" + this.activeStats[6]);
        if (teams[enemTeam][enemActiveMon].ability.compareTo("Thorny") ==0 && physSpec == 1){
            System.out.println(this.name + " was hurt!");
            this.activeStats[0] -= this.activeStats[0] / 16;
            this.activeStats[0] = this.activeStats[0] < 0 ? 0 :this.activeStats[0];
            System.out.println(this.name +": " +this.activeStats[0] + "/" + this.activeStats[6]);
        }
    }

    public static boolean getMoveAccuracy(String moveName, int randRoll, double thisAcc, double enemEvasion){
        int hitchance = 0;
        hitchance = (int)(randRoll * thisAcc - enemEvasion);
        switch(moveName){
            case ("Stone_Edge"):
                if (hitchance < 22){
                    return false;
                }
                break;
            case "Hydro_Pump":
                if (hitchance < 22){
                    return false;
                }
            case("Fire_Blast"):
            case ("Power_Whip"):
                if (hitchance < 17){
                    return false;
                }
                break;

            case "Zen_Headbutt":
            case "Rock_Slide":
                if (hitchance < 10){
                    return false;
                }
            case "Megahorn":
                if (hitchance < 15){
                    return false;
                }
            default:
                if (hitchance < 2){
                    return false;
                }
        }



        return true;
    }

    public void pokemon(){
        for (int i = 0; i < 7; i++){
            statMods[i] = 1.0;
        }
        for (int i = 0; i < 4; i++){
            moves[i] = "";
        }
    }

    public void pokemonSet(String nameInput, Scanner reader){
        name = nameInput;
        for(int i = 0; i < 6;i++){
            try {
                stats[i] = Integer.parseInt(reader.next());
            }
            catch(Exception e){
            }
        }
        for(int i = 0; i < 4; i++){
            moves[i] = reader.next();
        }

        item = reader.next();
        ability = reader.next();
        type1 = reader.next();
        type2 = reader.next();

        activeStats[0] = (2 * stats[0] + 31) + 60;
        activeStats[6] = activeStats[0];
        for (int i = 1; i < 6; i++){
            activeStats[i] = (2 * stats[i] + 36);
        }

    }



    public void atoString(){
        System.out.print(name + " " + ability + " " + item + " " + type1 + "/" + type2 + "\n");
        for (int i = 0; i < 4; i++){
            System.out.print(moves[i] + " ");
        }
        System.out.println();
        for (int i = 0; i < 6; i++){
            System.out.print(stats[i] + " ");
        }
         System.out.println("\n");
//        for (int i = 0; i < 6; i++){
//            System.out.print(statMods[i] + " ");
//        }


    }
}