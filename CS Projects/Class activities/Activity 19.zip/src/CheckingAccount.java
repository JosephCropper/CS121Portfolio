public class CheckingAccount extends AB_Account{
    private double overdraftLimit; //stasis

    public CheckingAccount(String in_accountholder, int in_accountnumber, double in_accountbalance, double in_overdraftLimit){
        super(in_accountholder, in_accountnumber, in_accountbalance);
        overdraftLimit = in_overdraftLimit;
    }

    //Get, Set

    public double getOverdraftLimit(){
        return overdraftLimit;
    }

    //

    @Override
    public String toString(){
        return ("--------------------------------------\n" +
                "(AccountHolder: " + accountHolder + ")\n" +
                "(AccountNumber: " + accountNumber + ")\n" +
                "(AccountBalance: " + accountBalance + ")\n" +
                "(OverdraftLimit: " + overdraftLimit +")");
    }

}
