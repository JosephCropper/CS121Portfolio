public class SavingsAccount extends AB_Account {
    private double interestRate; //stasis

    public SavingsAccount(String in_accountholder, int in_accountnumber, double in_accountbalance, double in_interestrate){
        super(in_accountholder, in_accountnumber, in_accountbalance);
        interestRate = in_interestrate;
    }

    //Get, Set

    public double getInterestRate(){
        return interestRate;
    }

    //

    @Override
    public String toString(){
        return ("--------------------------------------\n" +
                "(AccountHolder: " + accountHolder + ")\n" +
                "(AccountNumber: " + accountNumber + ")\n" +
                "(AccountBalance: " + accountBalance + ")\n" +
                "(InterestRate: " + interestRate + ")");
    }
}
