public class WithdrawalTransaction implements IN_Transaction{

    public WithdrawalTransaction(){}

    @Override
    public void deltaMoneyToAccount(SavingsAccount account, double deltaAmount){
        account.setAccountBalance(account.getAccountBalance() - deltaAmount);
    }

    @Override
    public void deltaMoneyToAccount(CheckingAccount account, double deltaAmount){
        account.setAccountBalance(account.getAccountBalance() - deltaAmount);
    }
}
