public interface IN_Transaction {
    void deltaMoneyToAccount(SavingsAccount account, double deltaAmount);
    void deltaMoneyToAccount(CheckingAccount account, double deltaAmount);

}
