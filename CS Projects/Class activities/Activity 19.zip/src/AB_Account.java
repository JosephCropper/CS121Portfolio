public abstract class AB_Account {
    protected String accountHolder; //stasis
    protected int accountNumber; //stasis
    protected double accountBalance; // fluid

    public AB_Account(String in_accountholder, int in_accountnumber, double in_accountbalance){
        accountHolder = in_accountholder;
        accountNumber = in_accountnumber;
        accountBalance = in_accountbalance;
    }

    //Set,Get

    public String getAccountHolder(){
        return accountHolder;
    }

    public int getAccountNumber(){
        return accountNumber;
    }

    public double getAccountBalance(){
        return accountBalance;
    }

    //

    protected void setAccountBalance(double newBalance){
        accountBalance = newBalance;
    }

    //

    public abstract String toString();

}
