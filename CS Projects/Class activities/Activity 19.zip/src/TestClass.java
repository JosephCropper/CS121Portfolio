public class TestClass {
    public static void testClass(){
        DepositTransaction deposit = new DepositTransaction();
        WithdrawalTransaction withdrawal = new WithdrawalTransaction();

        SavingsAccount accountone = new SavingsAccount("John Smith", 00001, 1000.00, .05);
        CheckingAccount accounttwo = new CheckingAccount("Jane Doe", 00002, 1500.55, .07);

        System.out.println(accountone.toString());
        deposit.deltaMoneyToAccount(accountone, 100.0);
        System.out.println("NEW: " + accountone.getAccountBalance());

        System.out.println(accounttwo.toString());
        withdrawal.deltaMoneyToAccount(accounttwo, 50.52);
        System.out.println("NEW: " + accounttwo.getAccountBalance());
    }
}
