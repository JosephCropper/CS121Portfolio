class Main{
    public static void main(String[] args){
//        DepositTransaction deposit = new DepositTransaction();
//        WithdrawalTransaction withdrawal = new WithdrawalTransaction();
        TestClass.testClass();

    }
}