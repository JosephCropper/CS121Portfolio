import java.util.Scanner;

public class Menu {
    Scanner scan = new Scanner(System.in);
    Pokedex dex = new Pokedex();

    public Menu(){
    }

    public void displayMenu(){
        String input;
        int inputint = 0;
        boolean loop = true;
        while (loop){
            System.out.printf("%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s", "**Menu**", "Please make a selection", "1) Add a pokemon", "2) Remove a pokemon",
                    "3) Display pokemon info", "4) Display all pokemon info", "5) Exit", ">> ");

            input = scan.next();
            try{
                inputint = Integer.parseInt(input);
            }
            catch (Exception e) {
            }
            switch (inputint){
                case 1:
                    createPokemon();
                    break;
                case 2:
                    deletePokemon();
                    break;
                case 3:
                    displayPokemon();
                    break;
                case 4:
                    displayAllPokemon();
                    break;
                case 5:
                    loop = false;
                    break;
                default:
                    System.out.println("Input unrecognized.. Please try again.");
            }

        }
    }


    private void createPokemon(){
        String name;
        int health, speed;
        System.out.println("Enter Pokemon's name: \n>> ");
        name = scan.next();
        System.out.println("Enter Pokemon's health: \n>> ");
        health = scan.nextInt();
        Pokemon newMon = new Pokemon(name, health);
        dex.addPokemon(newMon);
        boolean inloop = true;
        while (inloop){
            System.out.println("Enter move name, or \'q\' to quit.\n>> ");
            name = scan.next();
            if (name.compareTo("q") == 0){
                inloop = false;
            }
            else{
                System.out.println("Enter move power\n>> ");
                health = scan.nextInt();
                System.out.println("Enter move speed\n>> ");
                speed = scan.nextInt();
                Move newMove = new Move(name, health, speed);
                newMon.addMove(newMove);
            }
        }
        System.out.println("Pokemon added to dex!");
    }

    private void deletePokemon(){
        String input;
        System.out.println("Enter the name of the Pokemon you would like to delete \n>> ");
        input = scan.next();
        Pokemon deletepokemon = dex.getPokemon(input);
        if (deletepokemon == null){
            System.out.println("Pokemon not found");
        }
        else{
            dex.removePokemon(deletepokemon);
        }
    }

    private void displayPokemon(){
        String input;
        System.out.println("Enter the name of the pokemon you would like the information for\n>> ");
        input = scan.next();
        Pokemon findpokemon = dex.getPokemon(input);
        if (findpokemon == null){
            System.out.println("Pokemon not found");
        }
        else{
            System.out.println(findpokemon.toString());
        }
    }

    private void displayAllPokemon(){
        for (Pokemon a : dex.getAllPokemon()){
            System.out.println(a.toString());
        }
    }

}
